// Generated from testGrammar.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link amplParser}.
 */
public interface amplListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link amplParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(amplParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(amplParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#funcdef}.
	 * @param ctx the parse tree
	 */
	void enterFuncdef(amplParser.FuncdefContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#funcdef}.
	 * @param ctx the parse tree
	 */
	void exitFuncdef(amplParser.FuncdefContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#body}.
	 * @param ctx the parse tree
	 */
	void enterBody(amplParser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#body}.
	 * @param ctx the parse tree
	 */
	void exitBody(amplParser.BodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#varseq}.
	 * @param ctx the parse tree
	 */
	void enterVarseq(amplParser.VarseqContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#varseq}.
	 * @param ctx the parse tree
	 */
	void exitVarseq(amplParser.VarseqContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(amplParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(amplParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#vardecl}.
	 * @param ctx the parse tree
	 */
	void enterVardecl(amplParser.VardeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#vardecl}.
	 * @param ctx the parse tree
	 */
	void exitVardecl(amplParser.VardeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#statements}.
	 * @param ctx the parse tree
	 */
	void enterStatements(amplParser.StatementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#statements}.
	 * @param ctx the parse tree
	 */
	void exitStatements(amplParser.StatementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(amplParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(amplParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssign(amplParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssign(amplParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#r_do}.
	 * @param ctx the parse tree
	 */
	void enterR_do(amplParser.R_doContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#r_do}.
	 * @param ctx the parse tree
	 */
	void exitR_do(amplParser.R_doContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#input}.
	 * @param ctx the parse tree
	 */
	void enterInput(amplParser.InputContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#input}.
	 * @param ctx the parse tree
	 */
	void exitInput(amplParser.InputContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#output}.
	 * @param ctx the parse tree
	 */
	void enterOutput(amplParser.OutputContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#output}.
	 * @param ctx the parse tree
	 */
	void exitOutput(amplParser.OutputContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#pop}.
	 * @param ctx the parse tree
	 */
	void enterPop(amplParser.PopContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#pop}.
	 * @param ctx the parse tree
	 */
	void exitPop(amplParser.PopContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#when}.
	 * @param ctx the parse tree
	 */
	void enterWhen(amplParser.WhenContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#when}.
	 * @param ctx the parse tree
	 */
	void exitWhen(amplParser.WhenContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#r_while}.
	 * @param ctx the parse tree
	 */
	void enterR_while(amplParser.R_whileContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#r_while}.
	 * @param ctx the parse tree
	 */
	void exitR_while(amplParser.R_whileContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(amplParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(amplParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#relop}.
	 * @param ctx the parse tree
	 */
	void enterRelop(amplParser.RelopContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#relop}.
	 * @param ctx the parse tree
	 */
	void exitRelop(amplParser.RelopContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#simple}.
	 * @param ctx the parse tree
	 */
	void enterSimple(amplParser.SimpleContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#simple}.
	 * @param ctx the parse tree
	 */
	void exitSimple(amplParser.SimpleContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#addop}.
	 * @param ctx the parse tree
	 */
	void enterAddop(amplParser.AddopContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#addop}.
	 * @param ctx the parse tree
	 */
	void exitAddop(amplParser.AddopContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#term}.
	 * @param ctx the parse tree
	 */
	void enterTerm(amplParser.TermContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#term}.
	 * @param ctx the parse tree
	 */
	void exitTerm(amplParser.TermContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#mulop}.
	 * @param ctx the parse tree
	 */
	void enterMulop(amplParser.MulopContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#mulop}.
	 * @param ctx the parse tree
	 */
	void exitMulop(amplParser.MulopContext ctx);
	/**
	 * Enter a parse tree produced by {@link amplParser#factor}.
	 * @param ctx the parse tree
	 */
	void enterFactor(amplParser.FactorContext ctx);
	/**
	 * Exit a parse tree produced by {@link amplParser#factor}.
	 * @param ctx the parse tree
	 */
	void exitFactor(amplParser.FactorContext ctx);
}