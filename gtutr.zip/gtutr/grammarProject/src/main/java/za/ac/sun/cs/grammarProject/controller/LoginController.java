package za.ac.sun.cs.grammarProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.grammars.GrammarDao;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;

import java.util.Arrays;
import java.util.List;

@Controller
public class LoginController {

    private final GrammarDao grammarDao;
    private final UserDao userDao;

    @Autowired
    public LoginController(GrammarDao grammarDao, UserDao userDao) {
        this.grammarDao = grammarDao; this.userDao = userDao;
    }

    @GetMapping({"/"})
    public ModelAndView getLoginPage(ModelMap modelMap) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() != null
                && auth.getPrincipal() instanceof UserDetails) {
            UserDetails principal = (UserDetails) auth.getPrincipal();

            boolean isStudent = false;
            boolean isAdmin = false;

            for (GrantedAuthority authority : principal.getAuthorities()) {
                if (authority.getAuthority().equals("ROLE_STUDENT")) {
                    isStudent = true;
                } else if (authority.getAuthority().equals("ROLE_ADMIN")) {
                    isAdmin = true;
                }
            }

            if (isAdmin && !isStudent) {
                ModelAndView mav = new ModelAndView("select_grammar");
                List<Grammar> glist = grammarDao.getAllGrammars();
                mav.addObject("glist", glist);
                mav.addObject("name", principal.getUsername());
                return mav;
            } else if (isStudent && !isAdmin) {
                ModelAndView mav = new ModelAndView("select_grammar");
                List<Grammar> glist = grammarDao.getAllGrammars();
                mav.addObject("glist", glist);
                mav.addObject("name", principal.getUsername());
                return mav;
            }

            modelMap.put("username", ((UserDetails) auth.getPrincipal()).getUsername());
        }

      return null;
    }

}
