package za.ac.sun.cs.grammarProject.model;

import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.results.ResultStats;

import javax.servlet.annotation.WebServlet;
import java.util.*;

@WebServlet
public class ResultCalc {

    public static Map<Integer, List<ResultStats>> getUndisplayedClasses(Map<Integer, List<ResultStats>> nd, Map<Integer, List<ResultStats>> d) {
        Map<Integer, List<ResultStats>> classSet = new HashMap<>(nd);

        for(Map.Entry<Integer, List<ResultStats>> entry : nd.entrySet()) {
            if(d.containsKey(entry.getKey()) && d.get(entry.getKey()).size() != 0 ) {
                classSet.remove(entry.getKey());
            }
        }

        return classSet;
    }

    public static Map<Integer, List<ResultStats>> resultsToResClass(List<ResultStats> resultStats) {
        Map<Integer, List<ResultStats>> classMap = new HashMap<>();

        for (ResultStats rs : resultStats) {
            int cn = rs.getClassnum();
            if (classMap.containsKey(cn)) {
                classMap.get(cn).add(rs);
            } else {
                classMap.put(cn, new ArrayList<>(List.of(rs)));
            }
        }
        return classMap;
    }

    public static int getNumberOfSimilars(Map<Integer, List<ResultStats>> notDisplayed, int cn) {

        if (notDisplayed.containsKey(cn)) {
            return notDisplayed.get(cn).size();
        } else {
            return 0;
        }
    }


    public static int getNumberNew(List<Integer> dC, List<Integer> ndC) {

        ndC.removeAll(dC);

        int classnum = ndC.size();

        if(classnum == 1 && ndC.get(0) == 0) {
            classnum = 0;
        }

        return classnum;
    }

    public static String formatMessage(String txt, int l, int c) {

        String[] txtList = txt.split("\n");
        String html = "";

        for (int line = 0; line < txtList.length; line++) {
            if (l - 1 == line) {
                String[] thisLine = txtList[line].split("");

                for (int ch = 0; ch < thisLine.length; ch++) {
                    if (c == ch) {
                        html += "<span style=\"color: #c73a35; !important;\">" + thisLine[ch] + "</span>";
                    } else {
                        html += thisLine[ch];
                    }
                }
            } else {
                html += txtList[line];
            }
        }
        return html;
    }
}
