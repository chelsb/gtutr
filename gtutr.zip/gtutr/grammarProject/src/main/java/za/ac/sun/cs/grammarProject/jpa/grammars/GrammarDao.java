package za.ac.sun.cs.grammarProject.jpa.grammars;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;
import za.ac.sun.cs.grammarProject.jpa.testcases.TestcaseDao;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.servlet.ServletException;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Repository
public class GrammarDao {

    @PersistenceContext
    private EntityManager em;

    private final TestcaseDao testcaseDao;
    private final UserDao userDao;

    // Add a grammar to the DB

    @Autowired
    public GrammarDao(TestcaseDao testcaseDao, UserDao userDao) {
        this.testcaseDao = testcaseDao;
        this.userDao = userDao;
    }


    @Transactional
    public void persist(Grammar g) {
        em.persist(g);
    }

    @Transactional
    public void setModified(Grammar g, boolean b) {
        g.setModified(b);
        em.merge(g);
    }
    @Transactional
    public void update(Grammar g, int a) {
        g.setTest_count(a);
        em.merge(g);
    }

    @Transactional
    public void edit(Grammar g, int full_pen, int sim_pen,  int diff_pen, int fault_pen, int flip_pen, String starting_rule) {
        if(g.getFull_pen() != full_pen) {
            g.setFull_pen(full_pen);
        }

        if(g.getSim_pen() != sim_pen) {
            g.setSim_pen(sim_pen);
        }

        if(g.getDiff_pen() != diff_pen) {
            g.setDiff_pen(diff_pen);
        }

        if(g.getFault_pen() != fault_pen) {
            g.setFault_pen(fault_pen);
        }

        if(g.getFlip_pen() != flip_pen) {
            g.setFlip_pen(flip_pen);
        }

        if(!g.getStarting_rule().equals(starting_rule)) {
            g.setStarting_rule(starting_rule);
        }

        em.merge(g);
    }

    @Transactional
    public void updateStartingRule(Grammar g, String a) {
        g.setStarting_rule(a);
        em.merge(g);
    }

    @Transactional
    public void updateFullPen(Grammar g, int a) {
        g.setFull_pen(a);
        em.merge(g);
    }

    @Transactional
    public void updateFlipPen(Grammar g, int a) {
        g.setFlip_pen(a);
        em.merge(g);
    }

    @Transactional
    public void updateSimPen(Grammar g, int a) {
        g.setSim_pen(a);
        em.merge(g);
    }

    @Transactional
    public void updateDiffPen(Grammar g, int a) {
        g.setDiff_pen(a);
        em.merge(g);
    }

    @Transactional
    public void updateFaultPen(Grammar g, int a) {
        g.setFault_pen(a);
        em.merge(g);
    }

    @Transactional
    public void deleteGrammar(Grammar g) {
        em.remove(g);
    }

    // Get all grammars from the db
    public List<Grammar> getAllGrammars() {

        final CriteriaBuilder cb = em.getCriteriaBuilder();
        final CriteriaQuery<Grammar> criteriaQuery = cb.createQuery(Grammar.class);
        final Root<Grammar> criteria = criteriaQuery.from(Grammar.class);

        criteriaQuery.select(criteria);

        final TypedQuery<Grammar> query = em.createQuery(criteriaQuery);

        return query.getResultList();

    }

    public Grammar getGrammar(String grammar_name) {
        return em.find(Grammar.class, grammar_name);
    }

    private static String getFileName(Part part) {
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                String trimmed =  content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
                if(trimmed.contains("/")) {
                    return trimmed.split("/")[1];
                } else {
                    return trimmed;
                }
            }
        }
        return null;
    }


}
