package za.ac.sun.cs.grammarProject.jpa.testcases;

public class Suite {
    public String suite;
    public boolean isPositive;
    public boolean isPublic;
    public int num = 0;

    public Suite(String suite, boolean isPositive, boolean isPublic) {
        this.suite = suite;
        this.isPositive = isPositive;
        this.isPublic = isPublic;
    }

    public String getSuite() {
        return suite;
    }

    public void setNum() {
        this.num++;
    }

    public int getNum() {
        return num;
    }

    public void setSuite(String suite) {
        this.suite = suite;
    }

    public boolean isPositive() {
        return isPositive;
    }

    public void setPositive(boolean positive) {
        isPositive = positive;
    }

    public boolean isPublic() {
        return isPublic;
    }

    public void setPublic(boolean aPublic) {
        isPublic = aPublic;
    }


}
