package za.ac.sun.cs.grammarProject.jpa.users;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int user_id;

    private String username;

    @ManyToOne
    @JoinColumn(name = "grammar_name")
    private Grammar grammar_name;

    private int score = 0;
    private int penalties = 0;
    private int nos = 0;
    private int meter = 0;
    private String password = "";

    @Enumerated(EnumType.STRING)
    private UserType user_type;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "user_id")
    @Fetch(FetchMode.SELECT)
    private List<Submission> submissions = new ArrayList<>();

    public User() {
    }

    public User(String username, UserType userType) {
        this.username = username;
        this.user_type = userType;
    }

    public static String getCurrentUsername() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null && auth.getPrincipal() != null
                && auth.getPrincipal() instanceof UserDetails) {
            UserDetails principal = (UserDetails) auth.getPrincipal();
            return principal.getUsername();
        }

        return null;
    }

    public static boolean currentUserIsAdmin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() != null
                && auth.getPrincipal() instanceof UserDetails) {
            UserDetails principal = (UserDetails) auth.getPrincipal();

            for (GrantedAuthority authority : principal.getAuthorities()) {
                if (authority.getAuthority().equals("ROLE_ADMIN")) {
                    return true;
                }
            }
        }
        return false;
    }

    @Transactional
    public List<Submission> getSubmissions() {
        return submissions;
    }

    public UserType getUserType() {
        return user_type;
    }

    public void setUserType(UserType userType) {
        this.user_type = userType;
    }

    public String getPassword() {
        if (password == null || password.equals("")) {
            return getCurrentUsername() + "";
        } else {
            return password;
        }
    }

    public void setPassword(String name) {
        this.password = name;
    }

    public int getMeter() {
        return this.meter;
    }

    public void setMeter(int m) {
        this.meter = m;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public Grammar getGrammar() {
        return grammar_name;
    }

    public void setGrammar(Grammar grammar) {
        this.grammar_name = grammar;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getPenalties() {
        return penalties;
    }

    public void setPenalties(int penalties) {
        this.penalties = this.penalties + penalties;
    }

    public void resetPenalties() {
        this.penalties = 100;
    }

    public int getNos() {
        return nos;
    }

    public void setNos(int nos) {
        this.nos = nos;
    }

    public boolean isAdmin() {
        return getUserType().equals(UserType.ADMIN);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return score == user.score &&
                penalties == user.penalties &&
                nos == user.nos &&
                username.equals(user.username) &&
                user_type == user.user_type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, score, penalties, nos, user_type);
    }
}

