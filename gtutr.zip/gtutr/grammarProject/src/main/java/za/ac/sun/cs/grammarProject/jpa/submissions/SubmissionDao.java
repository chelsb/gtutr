package za.ac.sun.cs.grammarProject.jpa.submissions;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.users.User;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Repository
public class SubmissionDao {

    @PersistenceContext
    private EntityManager em;

    // Add a user to the DB
    @Transactional
    public void persist(Submission g) {
        em.persist(g);
    }

    // Set number of passes for this submission and update in progress
    @Transactional
    public void update(Submission g, int passes, String r) {
        g.setRulenames(r);
        g.setPasses(passes);
        g.setIp(false);
        em.merge(g);
    }

    @Transactional
    public void setFaultRequests(Submission g, int i) {
        g.setNum_fault_requests(g.getNum_fault_requests()+i);
        em.merge(g);
    }

    // Get all submissions from the db (Admin)
    @Transactional
    public List<Submission> getAllGrammarSubmissions(Grammar g) {
        final String gname = g.getGrammar_name();
        List<User> users = g.getUsers();
        users.removeIf(user -> !user.getGrammar().getGrammar_name().equals(gname));
        List<Submission> lst = users.stream()
                .flatMap((Function<User, Stream<Submission>>) user -> user.getSubmissions().stream())
                .collect(Collectors.toList());
        lst.removeIf(Submission::isIp);
        return lst;
    }

    @Transactional
    public Submission findOne(int sub_id) {
        return em.find(Submission.class, sub_id);
    }

    // Returns an unfinished submission
    public Submission getUnfinishedSubmissions() {
        Query query = em.createQuery("SELECT s FROM Submission s LEFT JOIN s.user_id u WHERE s.ip=True ORDER BY s.timestamp ASC");
        List<Submission> lst = query.getResultList();
        if (lst.size() > 0) {
            return lst.get(0);
        } else {
            return null;
        }
    }

    public List<Submission> getSubmissions(Grammar g) {
        Query query = em.createQuery("SELECT s FROM Submission s WHERE s.grammar_name='" + g.getGrammar_name() +"' ORDER BY s.timestamp ASC");
        List<Submission> lst = query.getResultList();

        return lst;
    }

    // Gets a user's specific submissions
    public List<Submission> getUserGrammarSubmission(User u, Grammar g) {
        List<Submission> lst = new ArrayList<>(u.getSubmissions());
        final String gname = g.getGrammar_name();
        lst.removeIf(submission -> !submission.getGrammar().getGrammar_name().equals(gname));
        lst.sort((o1, o2) -> {
            if (o1.getTimestamp().before(o2.getTimestamp())) {
                return 1;
            } else if (o1.getTimestamp().after(o2.getTimestamp())) {
                return -1;
            } else {
                return 0;
            }
        });

        return lst;
    }

    // Get number of submissions in progress for this user
    @Transactional
    public int getNumInProgressForUserGrammar(User u, Grammar g) {
        List<Submission> lst = new ArrayList<>(u.getSubmissions());
        String gname = g.getGrammar_name();
        lst.removeIf(submission -> !submission.getGrammar().getGrammar_name().equals(gname) || !submission.isIp());
        return lst.size();
    }

    @Transactional
    public void deleteAllSubmissions(Grammar g) {
        List<Submission> submissions = g.getSubmissions();
        for(Submission s : submissions) {
            em.remove(s);
        }
    }

    @Transactional
    public void deleteSubmission(int id) {
        Submission s = findOne(id);
        em.remove(s);
    }

    @Transactional
    public void remark(List<Submission>  subs) {
        for(Submission s : subs) {
            User u = s.getUser_id();

            u.setScore(0);
            u.setMeter(0);
            u.setPenalties(0);
            u.setNos(0);

            Query query = em.createQuery("DELETE FROM Result r WHERE r.submission.sub_id='" + s.getSub_id() +"'");
            query.executeUpdate();

            s.setIp(true);
            em.merge(u);
            em.merge(s);
        }

    }

    public List<List<Integer>> getResultStats(List<Submission> subs) {
        List<List<Integer>> passesForSubs = new ArrayList<>(subs.size());

        for(Submission s : subs) {
            List<Result> results = s.getResults();

            // tot(0) = positive passes tot(1) = negative passes tot(2) = positive fails tot(3) = negative fails
            List<Integer> tot = new ArrayList<>();
            tot.add(0,0);
            tot.add(1,0);
            tot.add(2,0);
            tot.add(3,0);

            if(!s.isIp()) {
                for(Result r : results) {
                    if(r.isPass()) {
                        if(r.getTestcase().isIs_positive()) {
                            tot.set(0, tot.get(0)+1);
                        } else {
                            tot.set(1, tot.get(1)+1);
                        }
                    } else {
                        if(r.getTestcase().isIs_positive()) {
                            tot.set(2, tot.get(2)+1);
                        } else {
                            tot.set(3, tot.get(3)+1);
                        }
                    }
                }
            }

            passesForSubs.add(tot);
        }

        return passesForSubs;
    }


}
