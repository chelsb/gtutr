package za.ac.sun.cs.grammarProject.jpa.results;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;

import java.util.List;

public class ResultStats {
    private Testcase tc;

    private boolean newtc;
    private int classnum;
    private List<Result> resultList;

    public ResultStats(Testcase tc,  List<Result> submissionList, int classnum) {
        this.tc = tc;
        this.resultList = submissionList;
        this.classnum = classnum;

        for(int i = 0; i < submissionList.size(); i++) {
            if(submissionList.size() == 1) {
                this.newtc = false;
            } else if (i == submissionList.size() - 1) {
                this.newtc = !submissionList.get(i).isPass() && submissionList.get(i-1).isPass();
            }
        }
    }

    public boolean isNewtc() {
        return newtc;
    }

    public void setNewtc(boolean newtc) {
        this.newtc = newtc;
    }

    public Testcase getTc() {
        return tc;
    }

    public List<Result> getResultList() {
        return resultList;
    }

    public int getClassnum() {
        return classnum;
    }

    /*
        Returns true if last result was failed
     */
    public boolean getLastError() {
        return !getLastResult().isPass();
    }

    public Result getLastResult() {
        return resultList.get(resultList.size()-1);
    }

}
