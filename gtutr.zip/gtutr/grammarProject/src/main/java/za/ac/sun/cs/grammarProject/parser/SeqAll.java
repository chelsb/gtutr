package za.ac.sun.cs.grammarProject.parser;

public class SeqAll {

    static int[][] M;
    static String[][] pointers;
    static int d = -10;

    // Needleman Wunsch algorithm for sequence alignment

    public static double NeedleManWunsch(String s1, String s2) {
        String[] A = s1.replaceAll(" ", "").replace("[", "").replace("]", "").split(",");
        String[] B = s2.replaceAll(" ", "").replace("[","").replace("]", "").split(",");

        if(s1.equals("[]") && s2.equals("[]")) {
            return 1;
        } else if(s1.equals("[]")) {
            return d * B.length;
        } else if(s2.equals("[]")) {
            return d * A.length;
        }

        M = new int[A.length+1][B.length+1];
        pointers = new String[A.length+1][B.length+1];

        M[0][0] = 0;
        pointers[0][0] = "";

        for(int i = 1; i <= A.length; i++) {
            M[i][0] = d*i;
            pointers[i][0] = "up";
        }

        for(int j = 1; j <= B.length; j++) {
            M[0][j] = d*j;
            pointers[0][j] = "left";
        }

        for(int i = 1; i <= A.length; i++) {
            for(int j = 1; j <= B.length; j++) {
                int diagSore = M[i-1][j-1] + score(A[i-1], B[j-1]);
                int upScore = M[i-1][j] + d;
                int leftScore = M[i][j-1] + d;
                int val = Math.max(diagSore, Math.max(upScore, leftScore));

                pointers[i][j] = "";
                if(val == diagSore) {
                    pointers[i][j] = "diag";
                } else if (val == upScore) {
                    pointers[i][j] = "up";
                } else {
                    pointers[i][j] = "left";
                }

                M[i][j] = val;
            }
        }

        return traceBack(A, B);
    }

    public static double traceBack(String[] A, String[] B) {

        int i = A.length;
        int j = B.length;

        StringBuilder newS = new StringBuilder();
        StringBuilder newS2 = new StringBuilder();

        while(i > 0 && j > 0) {
            String dir = pointers[i][j];

            // diag: the letters from two sequences are aligned
            // left: a gap is introduced in the left sequence
            // up: a gap is introduced in the top sequence.

            if(dir.equals("diag")) {
                newS.insert(0, " " + A[i - 1]);
                newS2.insert(0, " " + B[j - 1]);

                i--;
                j--;
            } else if (dir.equals("left")) {
                newS.insert(0, " -");
                newS2.insert(0, " " + B[j - 1]);

                j--;
            } else if (dir.equals("up")) {
                newS.insert(0, " " + A[i - 1]);
                newS2.insert(0, " -");

                i--;
            }
        }

        String[] newsSplit = newS.toString().split(" ");
        String[] news2Split = newS2.toString().split(" ");

        int finalScore = 0;

        for(int ind = 0; ind < newsSplit.length; ind++) {
            if(newsSplit[ind].equals("-")) {
                finalScore += d;
            } else if (newsSplit[ind].equals(news2Split[ind])) {
                finalScore += 7;
            } else if (!newsSplit[ind].equals(news2Split[ind])) {
                finalScore -= 5;
            }
        }

        double ffScore = (double) finalScore / (news2Split.length * 5) ;

        return ffScore;
    }

    public static int score(String s1, String s2) {
        if(s1.equals(s2)) {
            return 1;
        } else {
            return -1;
        }
    }
}
