package za.ac.sun.cs.grammarProject.parser;

import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;

import java.util.List;

public class ParserTestcase {
    private Testcase t;
    private String msg = "";
    private List<String> stack;
    private int character = 0;
    private int line = 0;
    private boolean pass;
    private boolean positive;
    private String tree = "";

    public ParserTestcase(Testcase t, String m, List<String> s, int character, int line,  boolean pass) {
        this.t = t;
        this.msg = m;
        this.stack = s;
        this.character = character;
        this.line = line;
        this.pass = pass;
        this.positive = t.isIs_positive();
    }

    public void setTree(String tree) {this.tree = tree;}

    public boolean passed() {
        return this.pass;
    }

    public boolean isPositive() {
        return this.positive;
    }

    public int getCharacter() {
        return character;
    }

    public int getLine() {
        return line;
    }

    public String getTree() {return this.tree;}

    public String getMsg() {
        return msg;
    }

    public List<String> getStack() {
        return stack;
    }

    public void setStack(List<String> stack) {
        this.stack = stack;
    }

    public Testcase getT() {
        return t;
    }

    @Override
    public boolean equals(Object t) {
        ParserTestcase cmp = (ParserTestcase) t;
        return cmp.t.getContent().equals(this.t.getContent());
    }

    @Override
    public String toString() {
        if (getStack() != null) {
            return getMsg() + " at " + getStack();
        } else {
            return getMsg();
        }

    }
}
