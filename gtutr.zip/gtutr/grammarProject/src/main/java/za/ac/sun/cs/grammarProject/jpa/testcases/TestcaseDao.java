package za.ac.sun.cs.grammarProject.jpa.testcases;

import junit.framework.TestCase;
import org.aspectj.weaver.ast.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.grammars.GrammarDao;
import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.results.ResultDao;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.submissions.SubmissionDao;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Repository
public class TestcaseDao {

    @PersistenceContext
    private EntityManager em;

    // Go through each file in this directory and add to DB
    @Transactional
    public void slurp(List<Testcase> testcases) {
        for(Testcase tc : testcases) {
            em.persist(tc);
        }
    }

    public List<Testcase> getAllTestCases(Grammar g) {
        Query query = em.createQuery("SELECT t FROM Testcase t WHERE t.grammar_name='"+g.getGrammar_name()+"' ORDER BY t.name");
        List<Testcase> tcs = query.getResultList();

        return tcs;
    }


    // Admin delete all test cases for suite toDelete
    @Transactional
    public void deleteTestCases(Grammar g, String toDelete) {

        int deleted = 0;
        List<Testcase> tcs = g.getTests();

        tcs.removeIf(testcase -> !testcase.getSuite().equals(toDelete));

/*        List<Result> lst = tcs.stream()
                .flatMap((Function<Testcase, Stream<Result>>) testcase -> testcase.getResults().stream())
                .collect(Collectors.toList());

        for(Result r : lst) {
            try {
                em.remove(r);
            } catch (Exception e) {

            }
        }*/


        for(Testcase t : tcs) {
            Query query = em.createQuery("DELETE FROM Result r WHERE r.testcase.tc_id='"+t.getTc_id()+"'");
            query.executeUpdate();
            em.remove(t);
            deleted++;

        }

        g.setTest_count(g.getTestCount()-deleted);
        g.setModified(false);
    }

    @Transactional
    public boolean deleteAllTestCases(Grammar g) {
        try {
            List<Testcase> tcs = g.getTests();

            List<Result> lst = tcs.stream()
                    .flatMap((Function<Testcase, Stream<Result>>) testcase -> testcase.getResults().stream())
                    .collect(Collectors.toList());
            for(Result r : lst) {
                em.remove(r);
            }

            for(Testcase t : tcs) {
                em.remove(t);
            }
            return true;
        } catch(Exception e){
            return false;
        }

    }

    @Transactional
    public boolean deleteTestCase(Grammar g, String tcName) {
        try {
            List<Testcase> tcs = g.getTests();

            for(Testcase tc : tcs) {
                if(tc.getName().equals(tcName)) {

                    Query query = em.createQuery("DELETE FROM Result r WHERE r.testcase.tc_id='" + tc.getTc_id() +"'");
                    query.executeUpdate();

                    query = em.createQuery("DELETE FROM Testcase t WHERE t.tc_id='" + tc.getTc_id() +"'");
                    query.executeUpdate();

                    query = em.createQuery("UPDATE Grammar g SET g.test_count = g.test_count - 1 WHERE g.grammar_name='" + g.getGrammar_name() +"'");
                    query.executeUpdate();

                    return true;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
            return false;
        }

        return false;
    }

    @Transactional
    public boolean flipPositive(Grammar g, String suite) {
        try {
            List<Testcase> tcs = g.getTests();

            for(Testcase tc : tcs) {
                if(tc.getSuite().equals(suite)) {
                    tc.flipPositive();
                    em.merge(tc);
                }
            }

            em.merge(g);

            return true;
        } catch(Exception e) {
            return false;
        }
    }

    @Transactional
    public boolean flipShown(Grammar g, String suite) {

        try {
            List<Testcase> tcs = g.getTests();

            for(Testcase tc : tcs) {
                if(tc.getSuite().equals(suite)) {
                    tc.flipShown();
                    em.merge(tc);
                }
            }

            em.merge(g);

            return true;
        } catch(Exception e) {
            return false;
        }
    }


    // Get list of test case statistics
    @Transactional
    public List<TestcaseStats> getTestCaseStats(Grammar g) {
        List<Testcase> tlist = g.getTests();
        List<TestcaseStats> statslist = new ArrayList<>();

        for(Testcase tc : tlist) {
            List<Result> results = tc.getResults();
            int nop = 0;
            int nof = 0;
            for(Result r : results) {
                if(r.getTestcase().isIs_positive() && !r.isPass()) {
                    nof++;
                } else if (r.getTestcase().isIs_positive() && r.isPass()) {
                    nop++;
                } else if (!r.getTestcase().isIs_positive() && !r.isPass()) {
                    nop++;
                } else if (!r.getTestcase().isIs_positive() && r.isPass()) {
                    nof++;
                }
            }

            statslist.add(new TestcaseStats(tc, nop, nof, false));
        }

        return statslist;
    }

    @Transactional
    public HashMap<String, Suite> getSuites(Grammar g) {
        List<Testcase> tcs = g.getTests();
        HashMap<String, Suite> suites = new HashMap<>();

        for(Testcase tc : tcs) {
            if(suites.containsKey(tc.getSuite())) {
                suites.get(tc.getSuite()).setNum();
            } else {
                suites.put(tc.getSuite(), new Suite(tc.getSuite(), tc.isIs_positive(), tc.isIs_public()));
            }
        }

        return suites;
    }


}
