package za.ac.sun.cs.grammarProject.parser;

import java.util.*;

public class ParserErrorclass {
    private int classNm = 0;

    // TestCases inside an error class are classified according to error message + stack
    // <error message, list of test cases with that error message>
    private HashMap<String, ArrayList<ParserTestcase>> testCases = new HashMap<>();

    private int classSize = 0;

    public HashMap<String,  ArrayList<ParserTestcase>> getTestCases() {
        return testCases;
    }

    public void addTestCase(ParserTestcase f) {
        if (testCases.containsKey(f.toString())) {
            if(!testCases.get(f.toString()).contains(f)){
                testCases.get(f.toString()).add(f);
                classSize++;
            }
        } else {
            ArrayList<ParserTestcase> tc = new ArrayList<>();
            tc.add(f);
            testCases.put(f.toString(),tc);
            classSize++;
        }
    }

    public int getClassSize() {
        return classSize;
    }

    public void setClassNm(int c) {
        this.classNm = c;
    }

    public int getClassNm() {
        return this.classNm;
    }


}
