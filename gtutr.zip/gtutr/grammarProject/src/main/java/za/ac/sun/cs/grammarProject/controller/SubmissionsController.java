package za.ac.sun.cs.grammarProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.grammars.GrammarDao;
import za.ac.sun.cs.grammarProject.jpa.results.ResultDao;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.submissions.SubmissionDao;
import za.ac.sun.cs.grammarProject.jpa.testcases.Suite;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;
import za.ac.sun.cs.grammarProject.jpa.testcases.TestcaseDao;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;
import za.ac.sun.cs.grammarProject.parser.RunParser;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
public class SubmissionsController {
    private final RunParser runParser;
    private final SubmissionDao submissionDao;
    private final ResultDao resultDao;
    private final TestcaseDao testcaseDao;
    private final GrammarDao grammarDao;
    private final UserDao userDao;

    @Autowired
    public SubmissionsController(RunParser runParser, SubmissionDao submissionDao, TestcaseDao testcaseDao, GrammarDao grammarDao, UserDao userDao, ResultDao resultDao) {
        this.runParser = runParser;
        this.submissionDao = submissionDao;
        this.testcaseDao = testcaseDao;
        this.grammarDao = grammarDao;
        this.userDao = userDao;
        this.resultDao = resultDao;
    }

    private static String getFileName(Part part) {
        String[] splt = part.getHeader("content-disposition").split(";");
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                String trimmed = content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
                return trimmed;
            }
        }
        return null;
    }

    // Called when admin clicks on `add submission'.
    @GetMapping({"/submit"})
    public ModelAndView displaySubmit() {
        ModelAndView mav = new ModelAndView("submit_admin");
        return mav;
    }

    // Called by admin to edit grammar
    @GetMapping({"/edit"})
    public ModelAndView edit(@RequestParam("grammar") String gramName) {

        Grammar grammar = grammarDao.getGrammar(gramName);

        ModelAndView mav = new ModelAndView("edit_admin");
        mav.addObject("grammar", grammar);

        String[] names = grammar.getTestNames();
        String name = "[";

        for (int i = 0; i < names.length; i++) {
            name += "'" + names[i] + "'";
            if (i < names.length - 1) {
                name += ",";
            }
        }
        name += "]";

        List<Suite> suites = new ArrayList<>(testcaseDao.getSuites(grammar).values());

        mav.addObject("suites", suites);
        mav.addObject("testnames", name);

        return mav;
    }

    // called when admin has edited a grammar
    @RequestMapping(value = "/editAdmin", method = RequestMethod.POST)
    public ModelAndView editGrammar(HttpServletRequest request) {

        Grammar g = grammarDao.getGrammar(request.getParameter("orig_grammar"));

        grammarDao.edit(g, Integer.parseInt(request.getParameter("full_pen")), Integer.parseInt(request.getParameter("sim_pen")), Integer.parseInt(request.getParameter("diff_pen")),
                Integer.parseInt(request.getParameter("fault_pen")), Integer.parseInt(request.getParameter("flip_pen")), request.getParameter("starting_rule"));

/*        Thread thread = new Thread() {
            public void run() {*/
        try {
            List<Testcase> testcases = new ArrayList<>();
            List<Part> parts = (List<Part>) request.getParts();
            ArrayList<Part> ps = new ArrayList<>();
            HashMap<String, Suite> suites = testcaseDao.getSuites(g);

            for (int i = 0; i < parts.size(); i++) {
                Part p = parts.get(i);

                if (p.getName().equals("tc")) {
                    ps.add(p);
                } else if (ps.size() != 0 && (p.getName().equals("pos") || p.getName().equals("neg"))) {
                    String positive = p.getName();
                    String hidden = parts.get(i + 1).getName();

                    boolean pos = true;
                    boolean hidd = true;
                    if (positive.equals("neg")) {
                        pos = false;
                    }
                    if (hidden.equals("shown")) {
                        hidd = false;
                    }

                    for (Part pp : ps) {
                        InputStream is = pp.getInputStream();
                        byte[] bytes = is.readAllBytes();
                        if (bytes.length != 0) {
                            String[] fileName = getFileName(pp).split("/");
                            testcases.add(new Testcase(g, fileName[1], bytes, !hidd, pos, fileName[0]));
                        }
                    }

                    ps = new ArrayList<>();
                } else if (p.getName().startsWith("suite_") && suites.containsKey(p.getName().substring(p.getName().indexOf("_") + 1))) {

                    String name = p.getName().substring(p.getName().indexOf("_") + 1);
                    String positive = parts.get(i + 1).getName();
                    String hidden = parts.get(i + 2).getName();

                    if (positive.equals("pos")) {
                        if (!suites.get(name).isPositive()) {
                            testcaseDao.flipPositive(g, name);
                        }
                    } else {
                        if (suites.get(name).isPositive()) {
                            testcaseDao.flipPositive(g, name);
                        }
                    }

                    if (hidden.equals("shown")) {
                        if (!suites.get(name).isPublic()) {
                            testcaseDao.flipShown(g, name);
                        }
                    } else {
                        if (suites.get(name).isPublic()) {
                            testcaseDao.flipShown(g, name);
                        }
                    }
                }
            }

            if (testcases.size() != 0) {
                testcaseDao.slurp(testcases);
                grammarDao.update(g, testcases.size() + g.getTest_count());
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ServletException e) {
            e.printStackTrace();
        }
        //      }
        //   };

        // thread.start();

        User u = userDao.findOneAdmin(User.getCurrentUsername());

        ModelAndView mav = new ModelAndView("select_grammar");
        List<Grammar> glist = grammarDao.getAllGrammars();
        mav.addObject("glist", glist);
        mav.addObject("user", u);
        mav.addObject("name", u.getUsername());

        return mav;
    }

    // Called by admin to delete a grammar
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public void delete(HttpServletRequest request, HttpServletResponse response) {
        Grammar g = grammarDao.getGrammar(request.getParameter("grammar_name"));

        grammarDao.setModified(g, true);
        System.out.println("Deleting grammar " + g.getGrammar_name());
        // delete results and test cases

        System.out.println("   Deleting test cases...");
        testcaseDao.deleteAllTestCases(g);
        System.out.println("   Deleting submissions...");
        submissionDao.deleteAllSubmissions(g);
        System.out.println("   Deleting users...");
        userDao.deleteUsers(g);
        grammarDao.deleteGrammar(g);

        System.out.println("Done deleting grammar " + g.getGrammar_name());

 /*       ModelAndView mav = new ModelAndView("select_grammar");
        List<Grammar> glist = grammarDao.getAllGrammars();

        mav.addObject("glist", glist);
        User u = userDao.findOneAdmin(User.getCurrentUsername());
        mav.addObject("user", u);
        mav.addObject("name", userDao.getName(u.getUsername()));
        return mav;*/
    }

    // Called by admin to delete all test cases from suite toDelete of a grammar
    @RequestMapping(value = "/deleteAllTestCase", method = RequestMethod.POST)
    public void deleteAllTestCase(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //  Thread thread = new Thread(() -> {

        Grammar g = grammarDao.getGrammar(request.getParameter("grammar_name"));
        String toDelete = request.getParameter("toDelete");
        System.out.println("Deleting test cases for suite " + toDelete);
        grammarDao.setModified(g, true);
        testcaseDao.deleteTestCases(g, toDelete);
        System.out.println("Done deleting test cases for suite " + toDelete);
        //  });

        //./thread.start();
    }

    // Called by admin to delete a single test cases of a grammar
    @RequestMapping(value = "/deleteTestCase", method = RequestMethod.POST)
    public void deleteTestCase(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Grammar g = grammarDao.getGrammar(request.getParameter("grammar_name"));
        String toDelete = request.getParameter("toDelete");

        boolean success = testcaseDao.deleteTestCase(g, toDelete);

        System.out.println("Test case " + toDelete + " for grammar " + g.getGrammar_name() + " has been deleted");

        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write("" + success);
    }

    // Check if grammar has test case deletions in progress
    @RequestMapping(value = "/checkGrammarModified", method = RequestMethod.POST)
    public void checkGrammarModified(HttpServletRequest request,
                                     HttpServletResponse response, @RequestParam(value = "grammar_name") String grammarName) throws IOException {

        System.out.println("Checking grammar: " + grammarName);

        //Grammar g = grammarDao.getGrammar(request.getParameter("grammar_name"));

        Grammar g = grammarDao.getGrammar(grammarName);

        boolean modified = g.isModified();

        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write("" + modified);
    }

    // Gets redirected when user submits submission
    @PostMapping({"/submitUser"})
    public RedirectView submitUserGrammar(@RequestParam("file") MultipartFile file, @RequestParam("grammar") String grammarID) throws IOException {

        // Create new submission
        Grammar g = grammarDao.getGrammar(grammarID);
        User u = userDao.findOne(User.getCurrentUsername(), g);
        submissionDao.persist(new Submission(u, file.getBytes(), g));

        return new RedirectView("usubmissions?id=" + g.getGrammar_name());
    }

    // Gets redirected when admin submits grammar
    @PostMapping({"/submitAdmin"})
    public ModelAndView submitAdminGrammar(HttpServletRequest request) {

        String gName = request.getParameter("grammar_name");

        if (grammarDao.getGrammar(gName) == null) {
            // Add admin's grammar submission to the DB
            Grammar newGrammar = new Grammar(request.getParameter("grammar_name"), request.getParameter("starting_rule"),
                    Integer.parseInt(request.getParameter("full_pen")), Integer.parseInt(request.getParameter("flip_pen")), Integer.parseInt(request.getParameter("sim_pen"))
                    , Integer.parseInt(request.getParameter("diff_pen")), Integer.parseInt(request.getParameter("fault_pen")));
            grammarDao.persist(newGrammar);

            grammarDao.setModified(newGrammar, true);

            System.out.println("Persisting data for grammar " + newGrammar.getGrammar_name());
            Thread thread = new Thread() {
                public void run() {
                    List<Testcase> testcases = new ArrayList<>();
                    List<Part> parts = null;
                    try {
                        parts = (List<Part>) request.getParts();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (ServletException e) {
                        e.printStackTrace();
                    }

                    ArrayList<Part> ps = new ArrayList<>();
                    for (int i = 0; i < parts.size(); i++) {
                        Part p = parts.get(i);

                        if (p.getName().equals("tc")) {
                            ps.add(p);
                        } else if (p.getName().equals("pos") || p.getName().equals("neg")) {
                            String positive = p.getName();

                            String hidden = parts.get(i + 1).getName();

                            boolean pos = true;
                            boolean hidd = true;
                            if (positive.equals("neg")) {
                                pos = false;
                            }
                            if (hidden.equals("shown")) {
                                hidd = false;
                            }

                            for (Part pp : ps) {
                                try {
                                    InputStream is = pp.getInputStream();

                                    byte[] bytes = is.readAllBytes();
                                    if (bytes.length != 0) {
                                        String[] fileName = getFileName(pp).split("/");
                                        testcases.add(new Testcase(newGrammar, fileName[1], bytes, !hidd, pos, fileName[0]));
                                    }
                                } catch (IOException e) {
                                    System.out.println("Test case not found: ");
                                    e.printStackTrace();
                                }

                            }

                            ps = new ArrayList<>();
                        }
                    }

                    testcaseDao.slurp(testcases);
                    grammarDao.update(newGrammar, testcases.size());
                    grammarDao.setModified(newGrammar, false);
                }
            };

            thread.start();
        }

        User u = userDao.findOneAdmin(User.getCurrentUsername());

        ModelAndView mav = new ModelAndView("select_grammar");
        List<Grammar> glist = grammarDao.getAllGrammars();
        mav.addObject("glist", glist);
        mav.addObject("user", u);
        mav.addObject("name", u.getUsername());

        return mav;

    }

    // Check if in progress submissions are still in progress
    @RequestMapping(value = "/checkForGrammarChanges", method = RequestMethod.POST)
    public void checkForChanges(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "json") String[] grammarList) throws IOException {

        boolean changed = false;
        for (String p : grammarList) {
            String id = p.replaceAll("[\\[\\]\"]", "");
            Grammar s = grammarDao.getGrammar(id);
            if (s != null) {
                if (!s.isModified()) {
                    changed = true;
                    break;
                }
            } else {
                changed = true;
            }
        }

        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write("" + changed);
    }

    // Called by admin to remark submissions for a specific grammar
    @RequestMapping(value = "/remarkGrammar", method = RequestMethod.POST)
    public void remark(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Grammar g = grammarDao.getGrammar(request.getParameter("grammar_name"));

        List<Submission> subs = submissionDao.getSubmissions(g);

        submissionDao.remark(subs);

        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write("Submission for grammar " + g.getGrammar_name() + " are being remarked");

    }


}
