package za.ac.sun.cs.grammarProject.model;

public class Login {
    private String id;

    private String password;

    private String role;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isAdmin() {
        if(this.role.equals("Admin")) {
            return true;
        } else {
            return false;
        }
    }

    public String getRole() {
        return this.role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
