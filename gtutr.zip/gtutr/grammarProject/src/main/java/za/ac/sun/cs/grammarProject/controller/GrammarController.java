package za.ac.sun.cs.grammarProject.controller;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.Gson;
import org.antlr.runtime.tree.Tree;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.grammars.GrammarDao;
import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.results.ResultDao;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.submissions.SubmissionDao;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;
import za.ac.sun.cs.grammarProject.jpa.testcases.TestcaseDao;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.List;

@Controller
public class GrammarController {
    private final GrammarDao grammarDao;
    private final TestcaseDao testcaseDao;
    private final SubmissionDao submissionDao;
    private final UserDao userDao;
    private final ResultDao resultDao;

    private String[] cols = {"#ad9767", "#a86337", "#a6442e", "#8a2f2f", "#730f14"};

    @Autowired
    private Gson gson;

    @Autowired
    public GrammarController(GrammarDao grammarDao, TestcaseDao testcaseDao, SubmissionDao submissionDao, UserDao userDao, ResultDao resultDao) {
        this.grammarDao = grammarDao;
        this.testcaseDao = testcaseDao;
        this.submissionDao = submissionDao;
        this.userDao = userDao;
        this.resultDao = resultDao;
    }

    // Redirects user to users_grammar
    @RequestMapping("/grammars")
    public ModelAndView getUserSubmissions(@RequestParam("id") String grammarID) {
        Grammar g = grammarDao.getGrammar(grammarID);
        User u = userDao.findOne(User.getCurrentUsername(), g);

        List<Submission> statslist = submissionDao.getUserGrammarSubmission(u, g);
        ModelAndView mav = new ModelAndView("grammars_user");

        mav.addObject("submissions", statslist);
        mav.addObject("grammar", g);
        mav.addObject("user", u);

        return mav;
    }

    // Initialize counts
    public void initSFL(HashMap<String, Double> a,  HashMap<String, Double> b, HashMap<String, Double> c, HashMap<String, Double> d, String[] rulenames) {
        for (String s : rulenames) {
            a.put(s, Double.MIN_VALUE);
            b.put(s,Double.MIN_VALUE);
            c.put(s,Double.MIN_VALUE);
            d.put(s,Double.MIN_VALUE);
        }
    }

    // Calculates and returns most suspicious rules of the grammar
    @RequestMapping(value = "/getTopRules", method = RequestMethod.POST)
    public void topRules(HttpServletRequest request, HttpServletResponse response) throws IOException {

        Submission s = submissionDao.findOne(Integer.parseInt(request.getParameter("sub")));
        List<Result> results = s.getResults();
        String[] rulenames = s.getRulenames();

        int numPasses = 0;
        int numFails = 0;

        // Number of times user has pressed button "more specific"..
        int heat = s.getNum_fault_requests();

        // If pressed == 0, this is called when the grammars page loaded
        // if pressed == 1, this is called when the user pressed on a button
        int pressed = Integer.parseInt(request.getParameter("pressed"));

        // If the page was loaded, not button pressed: load for previous heat (heat is not increasing)
        if(pressed == 0) {
            heat--;
        }

        // If pressed button and not max heat
        if(pressed != 0 && heat <= 4) {
            // number 1 and 2 display together, so skip to all 5
            if(heat == 4) {
                submissionDao.setFaultRequests(s, 2);
            } else {
                submissionDao.setFaultRequests(s, 1);
            }
        }

        heat = s.getNum_fault_requests();
        heat = Math.min(heat, 6);

        // rule,int : number of passing tests in which rule is executed
        HashMap<String, Double> ep = new HashMap<>();
        // rule,int number of failing tests in which rule is executed
        HashMap<String, Double> ef = new HashMap<>();
        // rule,int number of passing tests in which rule is not executed
        HashMap<String, Double> enp = new HashMap<>();
        // rule,int number of passing tests in which rule is not executed
        HashMap<String, Double> enf = new HashMap<>();

        initSFL(ep, ef, enp, enf, rulenames);

        for(Result r : results) {
            Testcase tt = r.getTestcase();
            boolean pos = tt.isIs_positive();
            boolean pass = true;
            if (pos && !r.isPass()) {
                pass = false;
            } else if(!tt.isIs_positive() && r.isPass()) {
                pass = false;
            }

            String[] stack = r.getStack().replace("[","").replace("]","").trim().split(",");
            for(String rule : stack) {
                    if(pass) {
                        if(ep.containsKey(rule)) {
                            numPasses++;
                            ep.put(rule, ep.get(rule)+1);
                        }

                    } else {
                        if(ef.containsKey(rule)) {
                            numFails++;
                            ef.put(rule, ef.get(rule)+1);
                        }

                    }

            }
        }

        for(String ss : rulenames) {
            enp.put(ss, numPasses - ep.get(ss));
            enf.put(ss, numFails - ef.get(ss));
        }

        TreeMap<Double, String> scores = new TreeMap<>(Collections.reverseOrder());

        for(String rule : rulenames) {
            double tarantscore = (ef.get(rule)/(ef.get(rule)+enf.get(rule)))/((ef.get(rule)/(ef.get(rule)+enf.get(rule))) + (ep.get(rule)/(ep.get(rule)+enp.get(rule))));
            if(!Double.isNaN(tarantscore) && tarantscore != 0.0) {
                scores.put(tarantscore, rule);
            }
        }

        List<String> toprules =  new ArrayList<>(scores.values());
        LinkedHashMap<String, String> ruleCols = new LinkedHashMap<>();

        response.setContentType("application/json");

        Gson gson = new Gson();

        String serial = "";
        if(toprules.size() >= heat-1) {
            if(toprules.size() > 5) {
                toprules = toprules.subList(0,5);
            } else {
                toprules = toprules.subList(0,toprules.size());
            }

            // if the user did not press a button, show the previous heat
            for(int i = 0; i < toprules.size() - (heat-1); i++) {
                ruleCols.put(toprules.get(i), cols[cols.length-1]);
            }

            for(int i =  toprules.size() - (heat-1); i < toprules.size(); i++) {
                ruleCols.put(toprules.get(i), cols[toprules.size()-i-1]);

            }

             serial = gson.toJson(ruleCols);
        }


        response.getWriter().write(serial.trim());
    }

    // Calculates and returns submission's num fault rule count
    @RequestMapping(value = "/getFaultNum", method = RequestMethod.POST)
    public void getFaultNum(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Submission s = submissionDao.findOne(Integer.parseInt(request.getParameter("sub")));

        int heat = s.getNum_fault_requests();

        response.setContentType("text/plain;charset=UTF-8");
        response.getWriter().write(""+heat);
    }
}
