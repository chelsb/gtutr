package za.ac.sun.cs.grammarProject.jpa.testcases;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.results.Result;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "testcases")
public class Testcase {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int tc_id;

    private String name;
    private byte[] content;

    public Grammar getGrammar_name() {
        return grammar_name;
    }

    @ManyToOne
    @JoinColumn(name = "grammar_name")
    private Grammar grammar_name;

    @OneToMany( cascade = CascadeType.ALL)
    @JoinColumn(name = "tc_id")
    private List<Result> results = new ArrayList<>();

    private boolean is_public;

    private boolean is_positive;

    private String suite;

    public Testcase(){}

    public Testcase(Grammar grammar, String name, byte[] content, boolean is_public, boolean is_positive, String suite) {
        this.grammar_name = grammar;
        this.name = name;
        this.content = content;
        this.is_public = is_public;
        this.is_positive = is_positive;
        this.suite = suite;
    }

    public boolean isIs_public() {
        return is_public;
    }

    public String getSuite() {
        return suite;
    }

    public void flipPositive() {
        if(is_positive) {
            is_positive = false;
        } else {
            is_positive = true;
        }
    }

    public void flipShown() {
        if(is_public) {
            is_public = false;
        } else {
            is_public = true;
        }
    }

    public int getTc_id() {
        return tc_id;
    }

    public boolean isIs_positive() {
        return this.is_positive;
    }

    public Grammar getGrammar() {
        return grammar_name;
    }

    public void setGrammar(Grammar grammar) {
        this.grammar_name = grammar;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[]  getContent() {
        return content;
    }

    public void setContent(byte[]  content) {
        this.content = content;
    }

    public List<Result> getResults() {
        return this.results;
    }

    public void removeResults() {
        results = new ArrayList<>();
    }

}
