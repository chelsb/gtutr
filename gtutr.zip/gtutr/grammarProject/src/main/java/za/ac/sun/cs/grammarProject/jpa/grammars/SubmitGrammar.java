package za.ac.sun.cs.grammarProject.jpa.grammars;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;

public class SubmitGrammar {
    private String grammar_name;
    private String parser_type;
    private MultipartFile tc_seen;
    private MultipartFile tc_hidden;
    private String starting_rule;

    public SubmitGrammar() {}

    public String getGrammar_name() {
        return grammar_name;
    }

    public void setGrammar_name(String name) {
        this.grammar_name = name;
    }

    public String getParser_type() {
        return parser_type;
    }

    public void setParser_type(String parser_type) {
        this.parser_type = parser_type;
    }

    public MultipartFile getTc_seen() {
        return tc_seen;
    }

    public void setTc_seen(MultipartFile tc_seen) {
        this.tc_seen = tc_seen;
    }

    public MultipartFile getTc_hidden() {
        return tc_hidden;
    }

    public void setTc_hidden(MultipartFile tc_hidden) {
        this.tc_hidden = tc_hidden;
    }

    public String getStarting_rule() {
        return starting_rule;
    }

    public void setStarting_rule(String starting_rule) {
        this.starting_rule = starting_rule;
    }
}
