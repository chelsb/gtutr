package za.ac.sun.cs.grammarProject.jpa.results;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;

import javax.persistence.*;

@Entity
@Table(name = "results")
public class Result {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int res_id;

    @ManyToOne
    @JoinColumn(name = "tc_id")
    private Testcase testcase;

    @ManyToOne
    @JoinColumn(name = "sub_id")
    private Submission submission;

    private int errorclass;
    private String error_message;
    private String stack;
    private String tree = "";
    private boolean pass;
    private boolean displayed;
    private int character;
    private int line;

    public Result() {}

    public Result(Testcase testcase, Submission submission, int errorclass, String error_message, String stack, boolean pass, boolean displayed, int character, int line, String tree) {
        this.testcase = testcase;
        this.submission = submission;
        this.errorclass = errorclass;
        this.error_message = error_message;
        this.stack = stack;
        this.pass = pass;
        this.displayed = displayed;
        this.character = character;
        this.line = line;
        this.tree = tree;
    }

    public String getTree() {return this.tree;}

    public int getCharacter() {
        return character;
    }

    public int getLine() {
        return line;
    }

    public boolean isDisplayed() {
        return displayed;
    }

    public void setDisplayed(boolean displayed) {
        this.displayed = displayed;
    }

    public int getRes_id() {
        return res_id;
    }

    public Testcase getTestcase() {
        return testcase;
    }

    public void setTestcase(Testcase testcase) {
        this.testcase = testcase;
    }

    public Submission getSubmission() {
        return submission;
    }

    public void setSubmission(Submission submission) {
        this.submission = submission;
    }

    public int getErrorclass() {
        return errorclass;
    }

    public void setErrorclass(int errorclass) {
        this.errorclass = errorclass;
    }

    public String getError_message() {
        return error_message;
    }

    public void setError_message(String error_message) {
        this.error_message = error_message;
    }

    public String getStack() {
        return stack;
    }

    public void setStack(String stack) {
        this.stack = stack;
    }

    public boolean isPass() {
        return pass;
    }

    public void setPass(boolean pass) {
        this.pass = pass;
    }

    @Override
    public String toString() {
        return "Pass: " + this.pass + "; Stack: " + this.stack + "; Error message: " + this.error_message + "; Displayed: " + this.isDisplayed() + "; Error class: " + this.errorclass;
    }
}
