package za.ac.sun.cs.grammarProject.controller;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.grammars.GrammarDao;
import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.results.ResultDao;
import za.ac.sun.cs.grammarProject.jpa.results.ResultStats;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.submissions.SubmissionDao;
import za.ac.sun.cs.grammarProject.jpa.testcases.TestcaseDao;
import za.ac.sun.cs.grammarProject.jpa.testcases.TestcaseStats;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;
import za.ac.sun.cs.grammarProject.jpa.users.UserType;
import za.ac.sun.cs.grammarProject.model.ResultCalc;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;

@Controller
public class DashboardController {

    private final GrammarDao grammarDao;
    private final TestcaseDao testcaseDao;
    private final SubmissionDao submissionDao;
    private final UserDao userDao;
    private final ResultDao resultDao;

    @Autowired
    private Gson gson;

    @Autowired
    public DashboardController(GrammarDao grammarDao, TestcaseDao testcaseDao, SubmissionDao submissionDao, UserDao userDao, ResultDao resultDao) {
        this.grammarDao = grammarDao;
        this.testcaseDao = testcaseDao;
        this.submissionDao = submissionDao;
        this.userDao = userDao;
        this.resultDao = resultDao;
    }

    private static boolean isAdmin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() != null
                && auth.getPrincipal() instanceof UserDetails) {
            UserDetails principal = (UserDetails) auth.getPrincipal();

            for (GrantedAuthority authority : principal.getAuthorities()) {
                if (authority.getAuthority().equals("ROLE_ADMIN")) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isStudent() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() != null
                && auth.getPrincipal() instanceof UserDetails) {
            UserDetails principal = (UserDetails) auth.getPrincipal();

            for (GrantedAuthority authority : principal.getAuthorities()) {
                if (authority.getAuthority().equals("ROLE_STUDENT")) {
                    return true;
                }
            }
        }
        return false;
    }

    @RequestMapping("/dashboardAdmin")
    public ModelAndView getDashAdmin(@RequestParam("grammar") String grammar, @RequestParam("role") String role) {
        if (role.equals("ADMIN")) {
            return getUserData(grammar);
        } else {
            return getUserSubmissions(grammar);
        }
    }

    @RequestMapping("/dashboardUser")
    public ModelAndView getDashUser(@RequestParam("grammar") String grammar) {
        return getUserSubmissions(grammar);
    }

    // Called by admin to see user data
    @RequestMapping("/users")
    public ModelAndView getUserData(@RequestParam("id") String grammarID) {
        Grammar g = grammarDao.getGrammar(grammarID);
        List<User> ulist = userDao.getAllGrammarUsers(g);

        ModelAndView mav = new ModelAndView("dashboard_admin");
        mav.addObject("users", ulist);

        int numUsers = ulist.size();
        int avMark = 0, avSubNum = 0;  double avPenalty = 0;
        int highestMark = 0;
        int lowestMark = Integer.MAX_VALUE;
        double highestPenalty = 0;
        double lowestPenalty = Integer.MAX_VALUE;

        for (User u : ulist) {
            avMark += (u.getScore() - u.getPenalties());
            avSubNum += u.getNos();
            avPenalty += u.getPenalties();

            if ((u.getScore() - u.getPenalties()) < lowestMark) {
                lowestMark = (u.getScore() - u.getPenalties());
            }
            if ((u.getScore() - u.getPenalties()) > highestMark) {
                highestMark = (u.getScore() - u.getPenalties());
            }

            if(u.getPenalties() < lowestPenalty) {
                lowestPenalty = u.getPenalties();
            }

            if(u.getPenalties() > highestPenalty) {
                highestPenalty = u.getPenalties();
            }
        }


        if (numUsers != 0) {
            avMark /= numUsers;
            avSubNum /= numUsers;
        }

        if(lowestMark == Integer.MAX_VALUE) {
            lowestMark = 0;
        }

        if(lowestPenalty == Integer.MAX_VALUE) {
            lowestPenalty = 0;
        }



        mav.addObject("numUsers", numUsers);
        mav.addObject("avMark", avMark);
        mav.addObject("avSubNum", avSubNum);
        mav.addObject("grammar", g);
        mav.addObject("lowestMark",lowestMark);
        mav.addObject("highestMark", highestMark);
        mav.addObject("avPenalty", avPenalty);
        mav.addObject("highPen", highestPenalty);
        mav.addObject("lowPen", lowestPenalty);

        return mav;
    }

    // Called by admin to see test case data
    @RequestMapping("/testcases")
    public ModelAndView getTestCases(@RequestParam("id") String grammarID) {
        Grammar g = grammarDao.getGrammar(grammarID);
        List<TestcaseStats> statslist = testcaseDao.getTestCaseStats(g);
        ModelAndView mav = new ModelAndView("testcases_admin");

        TestcaseStats temp;
        for (int i = 0; i < statslist.size(); i++) {
            for (int j = 0; j < statslist.size() - i - 1; j++) {
                if (statslist.get(j).getNof() < statslist.get(j + 1).getNof()) {
                    temp = statslist.get(j);
                    statslist.set(j, statslist.get(j + 1));
                    statslist.set(j + 1, temp);
                }
            }
        }

        mav.addObject("testcases", statslist);

        int numTestcases = statslist.size();
        int numPublic = 0;
        int numPrivate = 0;
        int currentlyPassing = 0;
        int currentlyFailing = 0;

        for (TestcaseStats tst : statslist) {
            if (tst.getTc().isIs_public()) {
                numPublic++;
            } else {
                numPrivate++;
            }

            if (tst.isCurrentlyPassing()) {
                currentlyPassing++;
            } else {
                currentlyFailing++;
            }

            User u = userDao.findOneAdmin(User.getCurrentUsername());

            mav.addObject("numTestcases", numTestcases);
            mav.addObject("numPublic", numPublic);
            mav.addObject("numPrivate", numPrivate);
            mav.addObject("currentlyPassing", currentlyPassing);
            mav.addObject("currentlyFailing", currentlyFailing);
            mav.addObject("user", u);
            mav.addObject("grammar", g);
        }

        return mav;
    }

    // Called by admin to see total submissions
    @RequestMapping("/submissions")
    public ModelAndView getSubmissions(@RequestParam("id") String grammarID) {
        Grammar g = grammarDao.getGrammar(grammarID);
        List<Submission> statslist = submissionDao.getAllGrammarSubmissions(g);
        ModelAndView mav = new ModelAndView("submissions_admin");
        mav.addObject("grammar", g);
        mav.addObject("submissions", statslist);
        return mav;
    }

    // Called by user to see his own submissions
    @RequestMapping("/usubmissions")
    public ModelAndView getUserSubmissions(@RequestParam("id") String grammarID) {
        Grammar g = grammarDao.getGrammar(grammarID);
        User u = userDao.findOne(User.getCurrentUsername(), g);

        List<Submission> statslist = submissionDao.getUserGrammarSubmission(u, g);
        int numInProgress = submissionDao.getNumInProgressForUserGrammar(u, g);
        ModelAndView mav = new ModelAndView("dashboard_user");

        List<List<Integer>> passes = submissionDao.getResultStats(statslist);
        mav.addObject("passes", passes);
        mav.addObject("submissions", statslist);
        mav.addObject("numInProgress", numInProgress);
        mav.addObject("grammar", g);
        mav.addObject("user", u);
        return mav;
    }

    // Check if in progress submissions are still in progress
    @RequestMapping(value = "/checkForChanges", method = RequestMethod.POST)
    public void checkForChanges(HttpServletRequest request, HttpServletResponse response, @RequestParam(value="json") String[] statslist) throws IOException {

        String changed = "false";
        for(String p : statslist) {
            int id = Integer.parseInt(p.replaceAll("[\\[\\]\"]", ""));
            Submission s = submissionDao.findOne(id);
            if(s != null) {
                if(!s.isIp()) {
                        changed = "true";
                        break;
                }
            } else {
                changed = "error";
            }
        }

        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write(""+changed);
    }

    // Called by user to see his results
    @RequestMapping("/results")
    public ModelAndView getResults(@RequestParam("id") String grammarID) {
        Grammar g = grammarDao.getGrammar(grammarID);
        User u = userDao.findOne(User.getCurrentUsername(), g);
        List<List<ResultStats>> results = resultDao.getResults(g, u);

        Map<Integer, List<ResultStats>> visible = ResultCalc.resultsToResClass(results.get(0));
        Map<Integer, List<ResultStats>> nvisible = ResultCalc.resultsToResClass(results.get(1));

        int nos = u.getNos();

        ModelAndView mav = new ModelAndView("results_user");
        mav.addObject("user", u);
        mav.addObject("grammar", g);

        mav.addObject("visible-res", visible);
        mav.addObject("nvisible-res", nvisible);
        mav.addObject("nos", nos);
        return mav;
    }

    @RequestMapping(value = "/penalize", method = RequestMethod.POST)
    public void penalize(HttpServletRequest request, HttpServletResponse response) throws IOException {

        Grammar g = grammarDao.getGrammar(request.getParameter("grammar_name"));
        User u = userDao.findOne(User.getCurrentUsername(), g);

        int penalty = Integer.parseInt(request.getParameter("pen"));
        int meter = u.getMeter();

        if (meter + penalty >= 100) {
            // If the total penalties is bigger than 100: user cannot possibly have positive mark anymore
            System.out.println("User penalties: " + u.getPenalties() + g.getFull_pen());
            if(u.getPenalties() + g.getFull_pen() >= 100) {
                userDao.setScore(u, 0);
                userDao.resetPenalties(u);
                userDao.updateMeter(u,0);
            } else {
                userDao.setPenalties(u,  g.getFull_pen());
                userDao.updateMeter(u,0);
            }
        } else {
            userDao.updateMeter(u,meter + penalty);
        }

        response.setContentType("application/json");
        Gson gson = new Gson();
        int[] vals = {u.getPenalties(), u.getScore(), u.getMeter()};

        String serial = gson.toJson(vals);
        response.getWriter().write(serial.trim());
    }

    @RequestMapping(value = "/getPenalties", method = RequestMethod.POST)
    public void getScore(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Grammar g = grammarDao.getGrammar(request.getParameter("grammar_name"));
        User u = userDao.findOne(User.getCurrentUsername(), g);

        response.setContentType("text/html;charset=UTF-8");

        if(u.getPenalties() >= 100) {
            response.getWriter().write("0");
        } else {
            response.getWriter().write("1");
        }

    }

}
