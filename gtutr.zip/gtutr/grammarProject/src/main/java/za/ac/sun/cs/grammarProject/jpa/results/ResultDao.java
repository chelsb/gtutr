package za.ac.sun.cs.grammarProject.jpa.results;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.submissions.SubmissionDao;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;
import za.ac.sun.cs.grammarProject.jpa.testcases.TestcaseDao;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;
import za.ac.sun.cs.grammarProject.model.ResultCalc;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;

@Repository
public class ResultDao {

    @PersistenceContext
    private EntityManager em;

    private final TestcaseDao testcaseDao;
    private final UserDao userDao;
    private final SubmissionDao submissionDao;

    @Autowired
    public ResultDao(TestcaseDao testcaseDao, UserDao userDao, SubmissionDao submissionDao) {
        this.testcaseDao = testcaseDao;
        this.userDao = userDao;
        this.submissionDao = submissionDao;
    }

    // Add a result to the DB
    @Transactional
    public void persist(List<Result> rr, Submission s, int score, int passes, String r) {

        // Update user score
        User g = s.getUser_id();
        System.out.println("Persisting results for user " + g.getUsername() + " for submission " + s.getSub_id());

        if(score > g.getScore()) {
            g.setScore(score);
        }

        g.setNos(g.getNos()+1);

        // update submission
        s.setRulenames(r);
        s.setPasses(passes);
        s.setIp(false);

        // push results
        for(Result res : rr) {
            em.persist(res);
        }

        em.merge(g);
        em.merge(s);

    }

    // Get all results from the db for user
    public List getUserResults(User u) {

        List<Submission> subs = u.getSubmissions();
        List<Result> results = new ArrayList<>();

        Collections.sort(subs, new Comparator<>() {
            @Override
            public int compare(Submission o1, Submission o2) {
                if (o1.getTimestamp().equals(o2.getTimestamp())) {
                    return 0;
                }
                boolean before = o1.getTimestamp().before(o2.getTimestamp());
                if (before) {
                    return -1;
                } else {
                    return 1;
                }
            }
        });

        for(Submission s : subs) {
            if(!s.isIp()) {
                results.addAll(s.getResults());
            }
        }
        return results;
    }

    @Transactional
    public ResultStats getResultForClass(Grammar g, User u, int rc) {
        Map<Integer, List<ResultStats>> resClassMap = ResultCalc.resultsToResClass(getResults(g, u).get(1));

        if (resClassMap.containsKey(rc)) {
            List<ResultStats> targetClass = resClassMap.get(rc);

            if (!targetClass.isEmpty()) {

                // If there is a result that has 'failed' - take that one instead of a 'passed' result
                ResultStats chosen = targetClass.get(0);
                for(ResultStats temp : targetClass) {
                    if(!temp.getLastResult().isPass()) {
                        chosen = temp;
                    }
                }

                chosen.getLastResult().setDisplayed(true);
                em.merge(chosen.getLastResult());
                return chosen;
            }
        }

        return null;
    }

    @Transactional
    public List<List<ResultStats>> getResults(Grammar g, User u) {
        List<Testcase> tlist = g.getTests();
        List<Result> resultList = new ArrayList<>(getUserResults(u));

        List<ResultStats> dList = new ArrayList<>();
        List<ResultStats> ndList = new ArrayList<>();

        for (Testcase t : tlist) {
            if (!t.isIs_public()) {
                continue;
            }

            ArrayList<Result> tcResults = new ArrayList<>();
            boolean tcDisplayed = false;
            int classnum = 0;
            for (int i = 0; i < resultList.size(); i++) {
                Result r = resultList.get(i);
                if (r.getTestcase().getTc_id() == t.getTc_id()) {
                    tcResults.add(r);
                    if (r.isDisplayed()) {
                        tcDisplayed = true;
                    }

                    classnum = r.getErrorclass();
                }
            }

            if (tcDisplayed) {
                dList.add(new ResultStats(t, tcResults, classnum));
            } else {
                ndList.add(new ResultStats(t, tcResults, classnum));
            }

            resultList.removeAll(tcResults);
        }

        return Arrays.asList(dList, ndList);
    }

    public boolean getUserLastDisplayed(User u, Testcase t) {
        List<Submission> subs = submissionDao.getUserGrammarSubmission(u, t.getGrammar());

        subs.removeIf(Submission::isIp);

        if (subs.size() > 0) {

            List<Result> results = subs.get(0).getResults();

            List<Result> newResults = new ArrayList<>(results);
            newResults.removeIf(result -> result.getTestcase().getTc_id() != t.getTc_id());

            if (newResults.size() > 0) {
                return newResults.get(0).isDisplayed();
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


    @Transactional
    public void updateResult(Result r) {
        r.setDisplayed(true);
        em.merge(r);
    }

    @Transactional
    public int getResultsForSubmission(Submission s) {
        int num = s.getResults().size();
        return num;
    }

    @Transactional
    public Result findOne(int id) {
        Result r = em.find(Result.class, id);

        return r;
    }

}
