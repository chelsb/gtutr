package za.ac.sun.cs.grammarProject.jpa.submissions;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.users.User;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "submissions")
public class Submission {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int sub_id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user_id;

    private byte[] content;
    private Timestamp timestamp;
    private int passes;
    private boolean ip;
    private String rulenames;
    private int num_fault_requests;

    @ManyToOne
    @JoinColumn(name="grammar_name")
    private Grammar grammar_name;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name="sub_id")
    @Fetch(FetchMode.SELECT)
    private List<Result> results = new ArrayList<>();

    public Submission() {}

    public Submission(User user_id, byte[]  content, Grammar grammar) {
        this.user_id = user_id;
        this.content = content;
        this.timestamp = new Timestamp(System.currentTimeMillis());
        this.ip = true;
        this.grammar_name = grammar;
    }

    public void setRulenames(String rulenames) {
        this.rulenames = rulenames;
    }

    public String getException() {
        return this.rulenames;
    }

    public String[] getRulenames() {
        return this.rulenames.replace("]", "").replace("[", "").trim().split(",");
    }

    public int getSub_id() {
        return this.sub_id;
    }

    public void setNum_fault_requests(int n) {
        this.num_fault_requests = n;
    }

    public int getNum_fault_requests() {
        return this.num_fault_requests;
    }

    public Grammar getGrammar() {
        return grammar_name;
    }

    public void setGrammar(Grammar grammar) {
        this.grammar_name = grammar;
    }

    public void setIp(boolean ip) {
        this.ip = ip;
    }

    public boolean isIp() {
        return ip;
    }

    public int getPasses() {
        return passes;
    }

    public void setPasses(int passes) {
        this.passes = passes;
    }

    public User getUser_id() {
        return user_id;
    }

    public byte[]  getContent() {
        return content;
    }

    public void setContent(byte[]  content) {
        this.content = content;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public List<Result> getResults() {
        return results;
    }
}


