package za.ac.sun.cs.grammarProject.jpa.users;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;


@Repository
public class UserDao {

    @PersistenceContext
    private EntityManager em;


    // Add a user to the DB
    @Transactional
    public void persist(User g) {
        em.persist(g);
    }

    @Transactional
    public void update(User g, int score) {
        if (score > g.getScore()) {
            g.setScore(score);
        }
        g.setNos(g.getNos() + 1);
        em.merge(g);
    }

    @Transactional
    public void setScore(User g, int score) {
        g.setScore(score);
        em.merge(g);
    }

    @Transactional
    public void setPenalties(User u, int pen) {
        u.setPenalties(pen);
        em.merge(u);
    }

    @Transactional
    public void resetPenalties(User u) {
        u.resetPenalties();
        em.merge(u);
    }

    @Transactional
    public void updateMeter(User g, int m) {
        g.setMeter(m);
        em.merge(g);
    }

    // Get all users from the db
    @Transactional
    public List<User> getAllGrammarUsers(Grammar g) {
        List<User> userList = g.getUsers();
        userList.removeIf(user -> user.getUserType() == UserType.ADMIN);
        return userList;
    }

    public User findOneAdmin(String userName) {
        Query query = em.createQuery("SELECT u FROM User u WHERE u.username='" + userName + "' AND u.user_type='ADMIN'");
        List<User> lst = query.getResultList();
        if (lst.isEmpty()) {
            System.out.println("Error: No admin with username: " + userName + " found");
            return null;
        } else {
            return lst.get(0);
        }
    }

    @Transactional
    public User findOne(@NonNull String userName, @NonNull Grammar g) {
        Query query = em.createQuery("SELECT u FROM User u WHERE u.username='" + userName + "' AND u.grammar_name='" + g.getGrammar_name() + "' AND u.user_type='STUDENT'");
        List<User> lst = query.getResultList();

        // If list is empty, then this grammar doesn't exist for this user
        if (lst.isEmpty()) {
            query = em.createQuery("SELECT u FROM User u WHERE u.username='" + userName + "' AND u.user_type='STUDENT'");
            lst = query.getResultList();
            for (User u : lst) {
                if (u.getGrammar() == null) {
                    u.setGrammar(g);
                    u = em.merge(u);
                    persist(u);
                    return u;
                } else if (u.getGrammar().getGrammar_name().equals(g.getGrammar_name())) {
                    return u;
                }
            }

            // Found username, but grammar was not null (Different grammar)
            User old = findSingle(userName);
            User newUser = new User(userName, UserType.STUDENT);
            newUser.setPassword(old.getPassword());

            newUser.setGrammar(g);
            persist(newUser);

            return newUser;
        } else {
            return lst.get(0);
        }

    }

    @Transactional
    public User findSingle(String username) {
        Query query = em.createQuery("SELECT u FROM User u WHERE u.username='" + username + "'");
        List<User> lst = query.getResultList();
        if (!lst.isEmpty()) {
            for (User u : lst) {
                if (u.getUserType() == UserType.ADMIN) {
                    return u;
                }
            }

            return lst.get(0);
        } else {
            return null;
        }
    }

    @Transactional
    public void deleteUsers(Grammar g) {
        List<User> users = g.getUsers();
        for (User u : users) {
            if (!u.isAdmin()) {
                em.remove(u);
            }
        }
    }

//    public User userExists(Login l) {
//        Query q = em.createQuery("SELECT u FROM User u WHERE u.username='"+l.getId()+"' AND u.grammar_name='"+Session.getCurrentSelectedGrammar().getGrammar_name()+"'");
//        try {
//            User u = (User) q.getSingleResult();
//            return u;
//        } catch (NoResultException err) {
//            return null;
//        }
//    }
}
