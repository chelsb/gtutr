package za.ac.sun.cs.grammarProject.parser;

import org.antlr.v4.Tool;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.tool.Grammar;
import org.antlr.v4.tool.ast.GrammarRootAST;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.results.ResultDao;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.submissions.SubmissionDao;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;
import za.ac.sun.cs.grammarProject.jpa.testcases.TestcaseDao;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

@Component
public class RunParser {

    private final static int maxClass = 3;
    private final String outputDir = "generated-sources/";
    private final SubmissionDao submissionDao;
    private final TestcaseDao testcaseDao;
    private final ResultDao resultDao;
    private final UserDao userDao;
    private List<String> rulenames;


    @Autowired
    public RunParser(SubmissionDao submissionDao, TestcaseDao testcaseDao, ResultDao resultDao, UserDao userDao) {
        this.submissionDao = submissionDao;
        this.testcaseDao = testcaseDao;
        this.resultDao = resultDao;
        this.userDao = userDao;
    }

    @Scheduled(fixedDelay = 1)
    public void run() {
        try {
            HashMap<String, ParserErrorclass> classes = new HashMap<>();
            HashMap<Integer, ParserErrorclass> finalClasses = new HashMap<>();
            HashMap<String, ParserTestcase> testcases = new HashMap<>();

            Submission currentSubmission = submissionDao.getUnfinishedSubmissions();
            za.ac.sun.cs.grammarProject.jpa.grammars.Grammar sourceGrammar;
            int totalTestCases;

            if (currentSubmission == null) {
                return;
            }

            System.out.println("Marking submission " + currentSubmission.getSub_id());

            if (currentSubmission.getResults().size() != 0) {
                System.out.println("Submission has results. Returning.");
                return;
            } else {
                sourceGrammar = currentSubmission.getGrammar();
                totalTestCases = sourceGrammar.getTest_count();
            }

            clean();
            List<Constructor<?>> constructors = generateSources(new String(currentSubmission.getContent()), sourceGrammar.getGrammar_name());

            // Run test cases
            int totFailed = 0;
            try {
                if (constructors == null) {
                    submissionDao.deleteSubmission(currentSubmission.getSub_id());
                    return;

                } else {
                    System.out.println("Running test cases...");
                    totFailed = runTestcases(currentSubmission, constructors.get(0), constructors.get(1), classes, finalClasses, testcases);
                    if(totFailed == -1) {
                        System.out.println("Submission " + currentSubmission.getSub_id() + " is faulty. Deleting.");
                        submissionDao.deleteSubmission(currentSubmission.getSub_id());
                        return;
                    }
                }
            } catch (IOException |
                    IllegalAccessException |
                    InvocationTargetException |
                    InstantiationException |
                    NoSuchMethodException e) {
                e.printStackTrace();
                return;
            }

            double totScore = (double) (totalTestCases - totFailed) / totalTestCases * 100.00;
            int tot = (int) totScore - currentSubmission.getUser_id().getPenalties();

            System.out.println("Organizing test cases...");
            organiseFailed(testcases, classes);
            System.out.println("Classifying test cases...");
            classifyFailed(classes, finalClasses);
            System.out.println("Creating results...");
            List<Result> finalList =  getfinalList(finalClasses, currentSubmission);;

            String finRuleNames = "";
            if(rulenames != null) {
                finRuleNames = rulenames.toString();
            }

            resultDao.persist(finalList, currentSubmission, tot, (totalTestCases - totFailed),finRuleNames);
            System.out.println("Done marking submission " + currentSubmission.getSub_id());

        } catch(NullPointerException e) {
            System.out.println("An error has occurred on the server: ");
            e.printStackTrace();
        }

    }

    // Generates, compiles and loads parser,lexer classes from the file
    private List<Constructor<?>> generateSources(String contents, String grammarName) {
        try {
            File fOutputDir = new File(outputDir);
            String[] args = {"-o", outputDir};

            Tool tool = new Tool(args);
            GrammarRootAST grast = tool.parseGrammarFromString(contents);
            Grammar g = tool.createGrammar(grast);
            // Might break it
            g.fileName = grammarName + ".g4";

            tool.process(g, true);

            // Compile source files
            DynamicClassCompiler dynamicClassCompiler = new DynamicClassCompiler();

             dynamicClassCompiler.compile(fOutputDir);

            Map<String, Class<?>> hm = new DynamicClassLoader().load(fOutputDir);

            Set<String> classNames = new HashSet<>(hm.keySet());
            classNames.removeIf(s -> !s.endsWith("Lexer"));

            Class<?> lexer = null;
            Class<?> parser = null;

            if (classNames.size() == 1) {
                lexer = hm.get(classNames.iterator().next());
            }

            classNames.clear();
            classNames.addAll(hm.keySet());
            classNames.removeIf(s -> !s.endsWith("Parser"));

            if (classNames.size() == 1) {
                parser = hm.get(classNames.iterator().next());
            }

            if (parser != null && lexer != null) {
                return Arrays.asList(lexer.getConstructor(CharStream.class), parser.getConstructor(TokenStream.class));
            } else {
                return null;
            }
        } catch (Exception e) {
            System.out.println("Could not create grammar Tool. Error with student submission. Rolling back.");
            return null;
        }
    }

    public int runTestcases(Submission submission, Constructor<?> lexerConstructor, Constructor<?> parserConstructor, HashMap<String, ParserErrorclass> failedClasses, HashMap<Integer, ParserErrorclass> finalClasses, HashMap<String, ParserTestcase> processedTests) throws IOException, IllegalAccessException, InvocationTargetException, InstantiationException, NoSuchMethodException {

        List<Testcase> testcases = testcaseDao.getAllTestCases(submission.getGrammar());

        int numfailed = 0;

        for (Testcase tc : testcases) {

            Lexer lexer = (Lexer) lexerConstructor.newInstance(CharStreams.fromString(new String(tc.getContent())));
            lexer.removeErrorListeners();
            lexer.addErrorListener(new ErrorListener(failedClasses, finalClasses, processedTests, tc));

            CommonTokenStream tokens = new CommonTokenStream(lexer);

            Parser parser = (Parser) parserConstructor.newInstance(tokens);
            parser.removeErrorListeners();
            parser.addErrorListener(new ErrorListener(failedClasses, finalClasses, processedTests, tc));
            rulenames = Arrays.asList(parser.getRuleNames());


            // Begin parsing at program rule
            Method parseEntrypoint = null;
            ParseTree tree = null;
            try {
                 parseEntrypoint = parser.getClass().getMethod(submission.getGrammar().getStarting_rule());
                 tree = (ParseTree) parseEntrypoint.invoke(parser);
            } catch(Exception e) {
                // starting rule is wrong or format of gammar is wrong
                try {
                    parseEntrypoint = parser.getClass().getMethod(rulenames.get(0));
                    tree = (ParseTree) parseEntrypoint.invoke(parser);
                } catch (Exception ee) {
                    return -1;
                }
            }

            // test did not 'fail' (positive or negative)
            if (!processedTests.containsKey(tc.getName())) {

                HashMap<Integer, String> ruleIndices = new HashMap<>();
                for (String s : rulenames) {
                    ruleIndices.put(parser.getRuleIndex(s), s);
                }

                ParseTreeWalker walker = new ParseTreeWalker();
                TreeListener treeListener = new TreeListener(ruleIndices);
                walker.walk(treeListener, tree);

                List<String> currentRuleStack = treeListener.getCurrentRuleStack();

                int dup = 5;
                while(currentRuleStack.size() > 50) {
                    currentRuleStack = removeDuplicates(currentRuleStack, dup);
                    dup--;

                    if(dup == 1) {
                        break;
                    }
                }

                if (!tc.isIs_positive()) {
                    numfailed++;
                }

                ParserTestcase ptc =  new ParserTestcase(tc, "", currentRuleStack, 0, 0, true);
                ptc.setTree(tree.toStringTree(parser));
                processedTests.put(tc.getName(),ptc);
            } else {
                //processedTests.get(tc.getName()).setTree(tree.toStringTree(parser));

                // test failed
                if(tc.isIs_positive()) {
                    numfailed++;
                }
            }

        }

        return numfailed;
    }

    public List<String> removeDuplicates(List<String> rulestack, int dup) {
        HashMap<String, Integer> seen = new HashMap<>();

        List<String> newStack = new ArrayList<>();

        for(String s : rulestack) {
            if(seen.containsKey(s)) {
                if(seen.get(s) < dup) {
                    seen.put(s, seen.get(s)+1);
                    newStack.add(s);
                }
            } else {
                seen.put(s, 1);
                newStack.add(s);
            }
        }

        return newStack;
    }

    // Organises failedTestCases into basic classes
    public void organiseFailed(Map<String, ParserTestcase> testcases, Map<String, ParserErrorclass> classes) {
        for (Map.Entry<String, ParserTestcase> entry : testcases.entrySet()) {
            String stack = entry.getValue().getStack().toString();
            ParserTestcase tc = entry.getValue();

            if (classes.containsKey(stack)) {
                classes.get(stack).addTestCase(tc);
            } else {
                classes.put(stack, new ParserErrorclass());
                classes.get(stack).addTestCase(tc);
            }
        }
    }

    // Classifies and puts together classes based on Needleman Wunsch algorithm
    public void classifyFailed(Map<String, ParserErrorclass> classes, Map<Integer, ParserErrorclass> finalClasses) {

        int classes_num = 1;

            List<String> cachedScoresUp = new ArrayList<>();
            List<String> cachedScoresDown = new ArrayList<>();

            for (Map.Entry<String, ParserErrorclass> entry : classes.entrySet()) {

                String testcase = entry.getKey();

                for (Map.Entry<String, ParserErrorclass> otherEntry : classes.entrySet()) {
                    if (entry.equals(otherEntry)) {
                        continue;
                    }

                    // Speeds up performance
                    if(cachedScoresUp.contains(otherEntry.getKey() + "-" + entry.getKey())  || cachedScoresUp.contains(entry.getKey() + "-" + otherEntry.getKey())) {
                        testcase = otherEntry.getKey();
                        break;
                    } else if (cachedScoresDown.contains(otherEntry.getKey() + "-" + entry.getKey())  || cachedScoresDown.contains(entry.getKey() + "-" + otherEntry.getKey())) {
                        continue;
                    }

                    double score = SeqAll.NeedleManWunsch(entry.getKey(), otherEntry.getKey());

                    if (score >= 0.62) {
                        cachedScoresUp.add(entry.getKey() + "-" + otherEntry.getKey());
                        testcase = otherEntry.getKey();
                        break;
                    } else {
                        cachedScoresDown.add(entry.getKey() + "-" + otherEntry.getKey());
                    }
                }


                if (entry.getValue().getClassNm() != 0) {
                    if (classes.get(testcase).getClassNm() != 0) {
                        int c = entry.getValue().getClassNm();
                        for (Map.Entry<String, ParserErrorclass> entries : classes.entrySet()) {
                            if (entries.getValue().getClassNm() == c) {
                                entries.getValue().setClassNm(classes.get(testcase).getClassNm());
                            }
                        }
                    } else {
                        classes.get(testcase).setClassNm(classes_num);
                    }
                } else {
                    if (classes.get(testcase).getClassNm() != 0) {
                        entry.getValue().setClassNm(classes.get(testcase).getClassNm());
                    } else {
                        entry.getValue().setClassNm(classes_num);
                        classes.get(testcase).setClassNm(classes_num);
                        classes_num++;
                    }
                }
            }

            for (int c = 1; c < classes_num; c++) {
                ParserErrorclass newC = new ParserErrorclass();
                for (Map.Entry<String, ParserErrorclass> entry : classes.entrySet()) {
                    if (entry.getValue().getClassNm() == c) {
                        for (Map.Entry<String, ArrayList<ParserTestcase>> tcList : entry.getValue().getTestCases().entrySet()) {
                            for (ParserTestcase tc : tcList.getValue()) {
                                newC.addTestCase(tc);
                            }
                        }
                    }
                }

                newC.setClassNm(c);
                finalClasses.put(c, newC);
            }
    }

    private List<Result> getfinalList(Map<Integer, ParserErrorclass> finalClasses, Submission currentSubmission) {
        int ncPos = 0;
        int ncNeg = 0;
        boolean seennc = false;
        List<Result> finalList = new ArrayList<>();

        for (Map.Entry<Integer, ParserErrorclass> entry : finalClasses.entrySet()) {
            int classnum = entry.getKey();
            ParserErrorclass eC = entry.getValue();

            int nPos = 0;
            int nNeg = 0;

            for (Map.Entry<String, ArrayList<ParserTestcase>> entry1 : eC.getTestCases().entrySet()) {
                ArrayList<ParserTestcase> tc = entry1.getValue();

                for (ParserTestcase tt : tc) {

                    boolean shouldDisplay = false;
                    Testcase t = tt.getT();

                    User u = currentSubmission.getUser_id();
                    boolean isLastDisplayed =  resultDao.getUserLastDisplayed(u, t);

                    // (If this test case is first in the class) || if the previous result was displayed
                    // If test case passed (negative) or failed (positive)
                    if(t.isIs_public()) {
                        if((t.isIs_positive() && !tt.passed()) && (u.getNos() == 0 || u.getScore() == 100)) {
                            if ((nPos < 3 && ncPos <= maxClass) || isLastDisplayed) {
                                shouldDisplay = true;
                                seennc = true;

                                nPos++;
                            }
                        } else if ((!t.isIs_positive() && tt.passed()) && (u.getNos() == 0 || u.getScore() == 100)) {
                            if ((nNeg < 3 && ncNeg <= maxClass) || isLastDisplayed) {
                                shouldDisplay = true;
                                seennc = true;

                                nNeg++;
                            }
                        } else {
                            // Display only if previous result was displayed
                            if (isLastDisplayed) {
                                shouldDisplay = true;
                            }
                        }

                        boolean pass = true;
                        if (tt.isPositive() && !tt.passed()) {
                            pass = false;
                        } else if (!tt.isPositive() && tt.passed()) {
                            pass = false;
                        }

                        finalList.add(new Result(t, currentSubmission, classnum, tt.getMsg(), tt.getStack().toString(), pass, shouldDisplay, tt.getCharacter(), tt.getLine(), tt.getTree()));
                    }
                }
            }

            if(seennc) {
                ncPos++;
                ncNeg++;
                seennc = false;
            }
        }

        return finalList;
    }

    private void clean() {
        try {
            // Test if "generated-sources" folder exists
            File fOutputDir = new File(outputDir);
            if(!fOutputDir.exists()) {
                fOutputDir.mkdir();
            }
            FileUtils.cleanDirectory(new File(outputDir));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ErrorListener extends BaseErrorListener {
        private final HashMap<String, ParserErrorclass> classes;
        private final HashMap<Integer, ParserErrorclass> finalClasses;
        private final Testcase testcase;
        private HashMap<String, ParserTestcase> testcases;

        private ErrorListener(HashMap<String, ParserErrorclass> classes, HashMap<Integer, ParserErrorclass> finalClasses, HashMap<String, ParserTestcase> testcases, Testcase testcase) {
            super();
            this.classes = classes;
            this.finalClasses = finalClasses;
            this.testcases = testcases;
            this.testcase = testcase;
        }


        public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e) {
            try {
                List<String> stack;

                if (recognizer instanceof Parser) {
                    stack = ((Parser) recognizer).getRuleInvocationStack();
                    Collections.reverse(stack);
                } else {
                    stack = Collections.emptyList();
                }

                if (testcases.containsKey(testcase.getName())) {
                    if (testcases.get(testcase.getName()).getStack().toString().length() < stack.toString().length()) {
                        testcases.put(testcase.getName(), new ParserTestcase(testcase, msg, stack, charPositionInLine, line, false));
                    }
                } else {
                    testcases.put(testcase.getName(), new ParserTestcase(testcase, msg, stack, charPositionInLine, line, false));
                }
            } catch (Exception pokemon) {
                pokemon.printStackTrace();
            }
        }
    }

    private static class TreeListener implements ParseTreeListener {
        private final HashMap<Integer, String> ruleIndices;
        private List<String> currentRuleStack = new ArrayList<>();

        private TreeListener(HashMap<Integer, String> ruleIndices) {
            super();
            this.ruleIndices = ruleIndices;
        }

        @Override
        public void visitTerminal(TerminalNode terminalNode) {

        }

        @Override
        public void visitErrorNode(ErrorNode errorNode) {

        }

        @Override
        public void enterEveryRule(ParserRuleContext parserRuleContext) {
            String rulename = ruleIndices.get(parserRuleContext.getRuleIndex());
            currentRuleStack.add(rulename);
        }

        @Override
        public void exitEveryRule(ParserRuleContext parserRuleContext) {

        }

        public List<String> getCurrentRuleStack() {
            return this.currentRuleStack;
        }
    }


}
