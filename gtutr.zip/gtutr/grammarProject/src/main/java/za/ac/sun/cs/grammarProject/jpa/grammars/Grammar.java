package za.ac.sun.cs.grammarProject.jpa.grammars;

import org.junit.Test;
import za.ac.sun.cs.grammarProject.jpa.submissions.Submission;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;
import za.ac.sun.cs.grammarProject.jpa.users.User;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "grammars")
public class Grammar {
    @Id
    private String grammar_name;

    private int test_count;
    private String starting_rule;
    private int full_pen;
    private int flip_pen;
    private int sim_pen;
    private int diff_pen;
    private int fault_pen;
    private boolean modified;

    @OneToMany
    @JoinColumn(name="grammar_name")
    private List<User> users;
    public List<User> getUsers() {
        return users;
    }

    @OneToMany
    @JoinColumn(name="grammar_name")
    private List<Submission> submissions;
    public List<Submission> getSubmissions() {return this.submissions;}

    public Grammar() { }

    public Grammar(String a, String c, int e, int f, int g, int h, int j) {
        this.grammar_name = a;
        this.starting_rule = c;

        if(f == 0 && g == 0 && h == 0 && j == 0) {
            this.full_pen = 0;
        } else {
            this.full_pen = e;
        }

        this.flip_pen = f;
        this.sim_pen = g;
        this.diff_pen = h;
        this.fault_pen = j;
        this.modified = false;
    }

    @OneToMany(mappedBy = "grammar_name")
    private List<Testcase> tests = new ArrayList<>();

    public List<Testcase> getTests() {
        return tests;
    }

    public String[] getTestNames() {
        List<Testcase> lst = getTests();
        String[] names = new String[lst.size()];

        for(int i = 0 ; i < lst.size(); i++) {
            Testcase tc = lst.get(i);
            names[i] = tc.getName();
        }

        return names;
    }

    public String getStarting_rule() {
        return starting_rule;
    }

    public void setModified(boolean modified) {
        this.modified = modified;
    }

    public boolean isModified() {
        return modified;
    }

    public int getTest_count() {
        return test_count;
    }

    public void setTest_count(int not) {
        this.test_count = not;
    }

    public int getTestCount() {
        return this.test_count;
    }

    public String getGrammar_name() {
        return grammar_name;
    }

    public void setGrammar_name(String s) {this.grammar_name = s;}

    public void setStarting_rule(String s) {this.starting_rule = s;}

    public int getFull_pen() {
        return full_pen;
    }

    public void setFull_pen(int full_pen) {
        this.full_pen = full_pen;
    }

    public int getFlip_pen() {
        return flip_pen;
    }

    public void setFlip_pen(int flip_pen) {
        this.flip_pen = flip_pen;
    }

    public int getSim_pen() {
        return sim_pen;
    }

    public void setSim_pen(int sim_pen) {
        this.sim_pen = sim_pen;
    }

    public int getDiff_pen() {
        return diff_pen;
    }

    public void setDiff_pen(int diff_pen) {
        this.diff_pen = diff_pen;
    }

    public int getFault_pen() {
        return fault_pen;
    }

    public void setFault_pen(int fault_pen) {
        this.fault_pen = fault_pen;
    }

    @Test
    public void testCreation() {
        Grammar g = new Grammar("a", "b", 1, 2, 3, 4, 5);

    }
}
