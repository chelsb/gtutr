package za.ac.sun.cs.grammarProject.controller;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
import za.ac.sun.cs.grammarProject.jpa.grammars.GrammarDao;
import za.ac.sun.cs.grammarProject.jpa.results.Result;
import za.ac.sun.cs.grammarProject.jpa.results.ResultDao;
import za.ac.sun.cs.grammarProject.jpa.results.ResultStats;
import za.ac.sun.cs.grammarProject.jpa.testcases.Testcase;
import za.ac.sun.cs.grammarProject.jpa.users.User;
import za.ac.sun.cs.grammarProject.jpa.users.UserDao;
import za.ac.sun.cs.grammarProject.model.ResultCalc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Null;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
public class ResultController {

    private final ResultDao resultDao;
    private final UserDao userDao;
    private final GrammarDao grammarDao;

    @Autowired
    public ResultController(ResultDao resultDao, UserDao userDao, GrammarDao grammarDao) {
        this.resultDao = resultDao;
        this.userDao = userDao;
        this.grammarDao = grammarDao;
    }

    // Called by jquery
    @RequestMapping(value = "/getSimilarTestcase", method = RequestMethod.POST)
    public void getResponse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int cn = Integer.parseInt(request.getParameter("cn"));
        int rw = Integer.parseInt(request.getParameter("rw"));
        Grammar targetGrammer = grammarDao.getGrammar(request.getParameter("gn"));
        User targetUser = userDao.findOne(User.getCurrentUsername(), targetGrammer);

        ResultStats stc = resultDao.getResultForClass(targetGrammer, targetUser, cn);

        Map<Integer, List<ResultStats>> resultClassMap = ResultCalc.resultsToResClass(resultDao.getResults(targetGrammer, targetUser).get(1));

        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write(getHTML(stc, resultClassMap, rw, 0));
    }

    private static String getHTML(ResultStats rs, Map<Integer, List<ResultStats>> nonDisplayed, int rw, int newtc) {

        String html = "";
        try {
            Testcase t = rs.getTc();
            List<Result> resList = rs.getResultList();

            html = "<div class=\"ctr part_" + t.getTc_id() + "\" style=\"width: " + rw + "px !important;\">";

            if (newtc == 1 && rs.getLastError() && ResultCalc.getNumberOfSimilars(nonDisplayed, rs.getClassnum()) > 0) {
                html += "<div class=\"ctd es beg\">" +
                        "<button id=\"another_" + t.getTc_id() + "\" class=\"btn active border rounded-0\" style=\"background-color: rgb(35,39,43);color: aliceblue; font-size:8px\"" +
                        "onclick=\"getSimilar(" + t.getTc_id() + "," + rs.getClassnum() + "," + rw + ")\"" +
                        "data-toggle=\"tooltip\" title=\"Penalty meter increase:" + t.getGrammar().getSim_pen() + "%\"" +
                        ">More</button>" +
                        "</div>" +
                        "<div class=\"ctd es start\" style=\"margin: auto; padding-bottom: 15px;\" ><p\n" +
                        "                                            data-toggle=\"tooltip\"\n" +
                        "                                            title=\"Class  " + rs.getClassnum()+ "\">\n" +
                        "                                    </p></div>";
            } else if (newtc == 1) {
                html += "<div class=\"ctd es\"></div><div class=\"ctd es mid\" style=\"margin: auto; padding-bottom: 15px;\"><p style=\"font-size: 10px; text-decoration: underline; background-color: #f8f9fa !important;\">Class " + rs.getClassnum() + "</p></div>";
                html += "<div class=\"ctd es start\" style=\"margin: auto; padding-bottom: 15px;\" ><p\n" +
                        "                                            data-toggle=\"tooltip\"\n" +
                        "                                            title=\"Class  " + rs.getClassnum() + "\">\n" +
                        "                                    </p></div>";
            } else {
                html += "<div class=\"ctd es\"></div><div class=\"ctd es mid\"></div>";
            }

            if(t.isIs_positive()) {
                html += "<div class=\"ctd tc\" data-toggle=\"tooltip\"\n" +
                        "                      title=\"Click here to see test case content. This test case is positive (meant to pass).\">>\n" +
                        "<a data-toggle=\"collapse\" data-target=\"#display_" + t.getTc_id() + "\">+" + t.getName() + "</a>\n" +
                        " </div>";
            } else {
                html += "<div class=\"ctd tc\" data-toggle=\"tooltip\"\n" +
                        "                      title=\"Click here to see test case content.  This test case is negative (meant to fail).\">>\n" +
                        "<a data-toggle=\"collapse\" data-target=\"#display_" + t.getTc_id() + "\">-" + t.getName() + "</a>\n" +
                        " </div>";
            }


            Result lastResult = null;
            for (int j = 0; j < resList.size(); j++) {
                Result r = resList.get(j);
                if (r.isDisplayed()) {
                    if (r.isPass()) {
                        if (r.getTestcase().isIs_positive()) {
                            html += "<div class=\"ctd pass dot\" data-toggle=\"tooltip\"  title=\"Test passed successfully! Click here to see rule stack for submission " + (j + 1) + "\" >\n" +
                                    " <a data-toggle=\"collapse\" data-target=\"#error_" + r.getRes_id() + "\"><i class=\"fa fa-check\" style=\"font-size:48px;color:#142914;\"></i></a>" +
                                    "</div>";
                        } else {
                            html += "<div class=\"ctd pass dot\" data-toggle=\"tooltip\"  title=\"Test failed successfully! Click here to see rule stack and error for submission " + (j + 1) + "\" >\n" +
                                    " <a data-toggle=\"collapse\" data-target=\"#error_" + r.getRes_id() + "\"><i class=\"fa fa-remove\" style=\"font-size:48px;color:#142914;\"></i></a>" +
                                    "</div>";
                        }

                    } else {
                        if (r.getTestcase().isIs_positive()) {
                            html += "<div class=\"ctd fail dot\" data-toggle=\"tooltip\"\n" +
                                    "title=\"Test passed unsuccessfully! Click here to see rule stack and error for submission" + (j + 1) + "\">\n" +
                                    "<a data-toggle=\"collapse\" data-target=\"#error_" + r.getRes_id() + "\"><i class=\"fa fa-remove\" style=\"font-size:48px;color:#340000;\"></i></a>\n" +
                                    "</div>";
                        } else {
                            html += "<div class=\"ctd fail dot\" data-toggle=\"tooltip\"\n" +
                                    "title=\"Test failed unsuccessfully! Click here to see rule stack for submission" + (j + 1) + "\">\n" +
                                    "<a data-toggle=\"collapse\" data-target=\"#error_" + r.getRes_id() + "\"><i class=\"fa fa-check\" style=\"font-size:48px;color:#340000;\"></i></a>\n" +
                                    "</div>";
                        }

                    }

                } else {
                    html += "<div class=\"ctd unk dot\" id=\"" + r.getRes_id() + "-res\"  data-toggle=\"tooltip\"\n" +
                            "title=\"Click here to flip. Penalty meter increase: " + r.getSubmission().getGrammar().getFlip_pen() + "%\">\n" +
                            "<p><i onclick=\"flipResult(" + r.getRes_id() + "," + (j + 1) + ")\" class=\"fa fa-question\" style=\"font-size:48px;color:#4b350b\"></i></p>\n" +
                            "</div>";
                }
                lastResult = r;
            }

            html += "<div class=\"ctd es\" style=\"color: red;\">";
            if (rs.isNewtc()) {
                html += " <p data-toggle=\"tooltip\"\n" +
                        "title=\"This test case was passing in the previous submission but is now failing!\" >!</p>";
            }
            html += "</div>";


            html += "</div><div class=\"ctr collapse part_\"+t.getTc_id()+\"\" id=\"display_" + t.getTc_id() + "\">\n" +
                    "<div class=\"ctd es\"></div><div class=\"ctd es des\"></div>" +
                    "<div class=\"ctd cl\" style=\"width: " + rw + "px !important;\" >\n" +
                    "<label style=\"width: 100%;\">\n";

            if ((lastResult.isPass() && lastResult.getTestcase().isIs_positive()) || (!lastResult.isPass() && !lastResult.getTestcase().isIs_positive())) {
                html += "<div class=\"codeSnippit\" style=\"width: 100%;\">" + new String(t.getContent()) + "</div>\n";
            } else {
                html += "<div class=\"codeSnippit\" style=\"width: 100%;\">" + ResultCalc.formatMessage(new String(t.getContent()), lastResult.getLine(), lastResult.getCharacter()) + "</div>\n";

            }

            html += "</label>\n" +
                    "</div>\n" +
                    "</div>";

            for (Result r : resList) {
                html += " <div class=\"ctr collapse part_" +t.getTc_id()+ "\" id=\"error_" + r.getRes_id() + "\">\n" +
                        "<div class=\"ctd es\"></div><div class=\"ctd es ees\"></div>" +
                        "<div class=\"ctd cl\" style=\"width: " + rw + "px !important\" >\n" +
                        "<label style=\"width: 100%;\">\n";
                if((lastResult.isPass() && lastResult.getTestcase().isIs_positive()) || (!lastResult.isPass() && !lastResult.getTestcase().isIs_positive())) {
                    if(lastResult.getTree() == null || lastResult.getTree().equals("")) {
                        html += "<textarea class=\"codeSnippit error\"\n" +
                                "style=\"width: 100%;\">" +r.getStack() + "</textarea>";
                    } else {
                        html += "<textarea rows=\"2\" class=\"codeSnippit error\" style=\"width: 100%;\">" + "Rule stack: " + r.getStack()+ "\n" +
                                "<br>Parse tree: " + r.getTree() +
                                "<br></textarea>";
                    }


                } else {
                    if(lastResult.getTree() == null || lastResult.getTree().equals("")) {
                        html += "<textarea rows=\"2\" class=\"codeSnippit error\" style=\"width: 100%;\">\n" +
                                "Error: " +  r.getError_message() + "\n" +
                                "<br>at " + r.getStack() +
                                "</textarea>";
                    } else {
                        html += "<textarea rows=\"3\" class=\"codeSnippit error\" style=\"width: 100%;\">\n" +
                                "Error: " + r.getError_message() + "\n" +
                                "<br>at " + r.getStack() + "\n" +
                                "<br>Parse Tree: " + r.getTree() +
                                "</textarea>";
                    }

                }
                html += "</label>\n" +
                        "</div>\n" +
                        "</div>";
            }
        } catch (NullPointerException e) {
            System.out.println("Could not load html. Stacktrace: ");
            e.printStackTrace();
        }

        return html;
    }

    @RequestMapping(value = "/getNumSimilarTestcases", method = RequestMethod.POST)
    public void getNumber(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int cn = Integer.parseInt(request.getParameter("cn"));
        Grammar targetGrammer = grammarDao.getGrammar(request.getParameter("gn"));
        User targetUser = userDao.findOne(User.getCurrentUsername(), targetGrammer);
        Map<Integer, List<ResultStats>> notDisplayedResultClasses = ResultCalc.resultsToResClass(resultDao.getResults(targetGrammer, targetUser).get(1));

        String res = ResultCalc.getNumberOfSimilars(notDisplayedResultClasses, cn) + "";

        response.setContentType("text/plain;charset=UTF-8");
        response.getWriter().write(res);
    }

    // Gets new class that has not yet been displayed
    @RequestMapping(value = "/getNewTestcases", method = RequestMethod.POST)
    public void getNew(HttpServletRequest request, HttpServletResponse response) throws IOException {

        // Get grammar from grammar name
        Grammar targetGrammer = grammarDao.getGrammar(request.getParameter("gn"));
        // Get user from user name
        User targetUser = userDao.findOne(User.getCurrentUsername(), targetGrammer);

        List<List<ResultStats>> results = resultDao.getResults(targetGrammer, targetUser);
        Map<Integer, List<ResultStats>> nonDisplayedResults = ResultCalc.resultsToResClass(results.get(1));
        Map<Integer, List<ResultStats>> displayedResults = ResultCalc.resultsToResClass(results.get(0));

        // Returns key set of nonDisplayedResult
        Map<Integer, List<ResultStats>> unseenClasses = ResultCalc.getUndisplayedClasses(nonDisplayedResults, displayedResults);

        // Calculate undisplayed class with most failing tests
        int mostFailed = 0;
        int failed = 0;
        Map.Entry<Integer, List<ResultStats>> chosen = null;
        if(unseenClasses.size() > 0) {
            for(Map.Entry<Integer, List<ResultStats>> entry : unseenClasses.entrySet()) {
            /*if(entry.getValue().size() >= max) {
                biggest = entry;
                max = entry.getValue().size();
            }*/
                failed = 0;
                for(ResultStats rs : entry.getValue()) {
                    if(!rs.getLastResult().isPass()) {
                        failed++;
                    }
               /*     for(Result r : rs.getResultList()) {
                        if(!r.isPass()) {

                        }
                    }*/
                }

                if(failed >= mostFailed) {
                    mostFailed = failed;
                    chosen = entry;
                }
            }
        }


        ResultStats stc = resultDao.getResultForClass(targetGrammer, targetUser, chosen.getKey());
        int rw = Integer.parseInt(request.getParameter("rw"));

        results = resultDao.getResults(targetGrammer, targetUser);

        if(results.get(1) != null) {
            nonDisplayedResults = ResultCalc.resultsToResClass(results.get(1));
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().write(getHTML(stc, nonDisplayedResults, rw, 1));
        } else {
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().write("");
        }

    }

    @RequestMapping(value = "/getNumNewTestcases", method = RequestMethod.POST)
    public void getNumberNew(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.getParameterMap();


        Grammar targetGrammer = grammarDao.getGrammar(request.getParameter("gn"));
        User targetUser = userDao.findOne(User.getCurrentUsername(), targetGrammer);
        List<List<ResultStats>> rsList = resultDao.getResults(targetGrammer, targetUser);
        Map<Integer, List<ResultStats>> displayedResultClasses = ResultCalc.resultsToResClass(rsList.get(0));
        Map<Integer, List<ResultStats>> notDisplayedResultClasses = ResultCalc.resultsToResClass(rsList.get(1));

        int res = ResultCalc.getNumberNew(new ArrayList<>(displayedResultClasses.keySet()), new ArrayList<>(notDisplayedResultClasses.keySet())) ;

        response.setContentType("text/plain;charset=UTF-8");
        response.getWriter().write(res);
    }

    @RequestMapping(value = "/flipResult", method = RequestMethod.POST)
    public void flipResult(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Result r = resultDao.findOne(Integer.parseInt(request.getParameter("res")));

        resultDao.updateResult(r);

        response.setContentType("text/plain;charset=UTF-8");
        if(r.isPass()) {
            if(r.getTestcase().isIs_positive()) {
                response.getWriter().write("pass-positive");
            } else {
                response.getWriter().write("pass-negative");
            }

        } else {
            if(r.getTestcase().isIs_positive()) {
                response.getWriter().write("fail-positive");
            } else {
                response.getWriter().write("fail-negative");
            }

        }

    }
}
