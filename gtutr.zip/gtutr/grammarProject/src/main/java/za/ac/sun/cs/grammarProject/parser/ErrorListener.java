//package za.ac.sun.cs.grammarProject.parser;
//
//import org.antlr.v4.runtime.BaseErrorListener;
//import org.antlr.v4.runtime.Parser;
//import org.antlr.v4.runtime.RecognitionException;
//import org.antlr.v4.runtime.Recognizer;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import za.ac.sun.cs.grammarProject.jpa.SpringContext;
//
//import java.util.Collections;
//import java.util.List;
//
//@Component
//public class ErrorListener extends BaseErrorListener {
//
//    RunParser runParser = SpringContext.getBean(RunParser.class);
//
//    @Override
//    public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e) {
//
//        runParser.fileFailed = true;
//        List<String> stack = ((Parser) recognizer).getRuleInvocationStack();
//        Collections.reverse(stack);
//
//        if(runParser.failedTestCases.containsKey(runParser.currentTestcase.getName())) {
//            if(runParser.failedTestCases.get(runParser.currentTestcase.getName()).getStack().toString().length() < stack.toString().length()) {
//                runParser.failedTestCases.put(runParser.currentTestcase.getName(), new ParserTestcase(runParser.currentTestcase, msg, stack, charPositionInLine, line));
//            }
//        } else {
//            runParser.failedTestCases.put(runParser.currentTestcase.getName(), new ParserTestcase(runParser.currentTestcase, msg, stack, charPositionInLine, line));
//        }
//
//    }
//}
