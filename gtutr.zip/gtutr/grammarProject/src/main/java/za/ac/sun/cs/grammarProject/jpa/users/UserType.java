package za.ac.sun.cs.grammarProject.jpa.users;

public enum UserType {
    STUDENT, ADMIN
}
