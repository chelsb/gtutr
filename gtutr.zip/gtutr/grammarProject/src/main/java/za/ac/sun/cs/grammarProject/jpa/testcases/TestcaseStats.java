package za.ac.sun.cs.grammarProject.jpa.testcases;

public class TestcaseStats {
    private Testcase tc;
    private int nop;
    private int nof;
    private boolean currentlyPassing;

    public TestcaseStats(Testcase tc, int nop, int nof, boolean cp){
        this.tc = tc;
        this.nop = nop;
        this.nof = nof;
        this.currentlyPassing = cp;
    }

    public Testcase getTc() {
        return tc;
    }

    public int getNop() {
        return nop;
    }

    public int getNof() {
        return nof;
    }

    public boolean isCurrentlyPassing() {
        return currentlyPassing;
    }
}
