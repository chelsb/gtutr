//package za.ac.sun.cs.grammarProject.model;
//
//import za.ac.sun.cs.grammarProject.jpa.SpringContext;
//import za.ac.sun.cs.grammarProject.jpa.grammars.Grammar;
//import za.ac.sun.cs.grammarProject.jpa.users.User;
//import za.ac.sun.cs.grammarProject.jpa.users.UserDao;
//
//public class Session {
//    private static Login login;
//    private static User currentLoggedInUser;
//    private static Grammar currentSelectedGrammar;
//
//    public static Login getLogin() {
//        return login;
//    }
//
//    public static void setLogin(Login login) {
//        Session.login = login;
//    }
//
//    public static void setCurrentLoggedInUser() {
//        UserDao userDao = SpringContext.getBean(UserDao.class);
//        User u = userDao.userExists(login);
//        if (u == null) {
//            currentLoggedInUser = new User(Session.getCurrentSelectedGrammar(), login.getId(), 0, 0, 0);
//            userDao.persist(currentLoggedInUser);
//        } else {
//            currentLoggedInUser = u;
//        }
//    }
//
//    public static User getCurrentLoggedInUser() {
//        return currentLoggedInUser;
//    }
//
//    public static Grammar getCurrentSelectedGrammar() {
//        return currentSelectedGrammar;
//    }
//
//    public static void setCurrentSelectedGrammar(Grammar currentSelectedGrammar) {
//        Session.currentSelectedGrammar = currentSelectedGrammar;
//    }
//}
